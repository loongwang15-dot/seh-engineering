# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-character-definition/SKILL.md | bytes=13293 | chars=7972 | sha256=5ef132a861a4e5cc559b45be187b255ae0fd36ac110821101fed21007ad716c2 -->

---
name: ip-character-definition
description: "IP人物设定与亮点设计 Skill。用于IP Design Workflow Master在创建、完善、分析或重构IP核心人物设定时调用。读取Master提供的IP项目事实、用户已有信息、参考素材和原始IP形象，自动完成事实分析、人物身份推演、性格与视觉性格推演、IP亮点发现与视觉转译、人物故事、核心记忆点、Character DNA与Character Lock。默认不向用户询问人物设定问题；仅在事实冲突、关键事实无法合理推演或用户明确要求人工决定时请求确认。前台输出为16:9视觉化人物设定页面，文字精简、视觉优先、亮点优先。不得抢占三视图、色彩、表情、GIF、服装、场景、海报、条漫、文创等下游Skill的执行权。"
---

# IP人物设定 Skill
## Character Definition & IP Highlight Design

## 0. Skill身份

- 类型：核心IP设计推演Skill
- 上游：IP Design Workflow Master
- 下游：三视图、色彩规范、表情、GIF、服装、场景、海报、条漫、文创等Skill
- 核心职责：把项目事实与已有IP形象转化为完整、统一、可锁定的人物设定
- 核心输出：Character Spec / IP Highlight Spec / Character DNA / Character Lock / 16:9人物设定视觉页

---

# 1. 核心原则

本Skill遵循：

> 边界清、接口明、流程稳、能沉淀。

核心工作方式：

```text
Master项目事实
+
用户已有设定
+
参考素材
+
原始IP形象
        ↓
事实提取
        ↓
已有IP分析
        ↓
设计判断
        ↓
受约束发散
        ↓
IP亮点发现
        ↓
视觉转译
        ↓
人物设定综合
        ↓
自动校验
        ↓
Character Spec
        ↓
Character DNA
        ↓
Character Lock
```

本Skill不是人物设定问卷，不要求用户逐项填写人物属性。

---

# 2. 触发边界

## 2.1 触发

以下需求触发本Skill：

- 创建IP人物设定
- 完善IP人物设定
- 分析IP人物身份
- 设计IP人物定位
- 推演IP性格
- 推演IP年龄阶段或性别
- 分析IP视觉性格
- 提炼IP核心记忆点
- 分析地域、文化、产业并转化为IP设计亮点
- 建立IP亮点设计
- 建立Character DNA
- 建立Character Lock
- 完善已有IP人物核心设定

## 2.2 不触发

以下任务不由本Skill独立执行：

- 三视图生成/修改 → 三视图Skill
- 色彩规范/标准色 → 色彩规范Skill
- 表情包 → 表情Skill
- 动态GIF → GIF Skill
- 服装设计 → 服装Skill
- 职业场景 → 场景Skill
- 海报 → 海报Skill
- 条漫 → 条漫Skill
- 文创 → 文创Skill
- 汇报页面 → 汇报方案Skill

如果下游Skill发现Character Lock不存在，应请求Master调度本Skill，而不是自行重建人物设定。

---

# 3. 用户交互原则

## 3.1 默认不询问

本Skill运行后必须主动完成设计推演。

用户提供什么，就使用什么。

用户没有提供的信息：

1. 优先从Master上下文读取
2. 从已有IP形象和参考素材判断
3. 从项目、行业、地区、文化、产业、理念推演
4. 形成合理设计结论

不得为了补齐表格而主动连续询问用户。

## 3.2 允许询问的情况

仅以下情况允许请求用户确认：

### A. 事实冲突

例如不同资料对IP性别、地区、名称等核心事实描述不一致。

### B. 关键事实缺失且无法合理推演

例如项目要求明确人物身份，但所有资料都无法判断。

### C. 用户明确要求人工决定

例如用户明确表示年龄、性别或核心亮点由自己指定。

除此之外默认继续完成。

---

# 4. 输入接口

## 4.1 Master输入

```yaml
IP_PROJECT_CONTEXT:
  ip_name:
  region:
  organization:
  project_name:
  project_background:
  design_concept:
  industry:
  target_audience:
  application_scenarios:
  project_requirements:
  existing_ip_description:
  uploaded_references:
```

## 4.2 用户输入

```yaml
USER_PROVIDED_INFO:
  confirmed_facts:
  existing_character_description:
  special_requirements:
  forbidden_elements:
  preferred_elements:
```

## 4.3 资产

可读取：

- IP原始形象
- 草图
- 已有三视图
- 品牌资料
- PPT/PDF/Word
- 地域资料
- 文化资料
- 产业资料
- 服饰资料
- 建筑/地标资料
- 已有宣传物料
- 其他Master提供的参考资产

---

# 5. 事实与推演分离

内部必须区分：

```text
FACT
用户/Master明确提供的事实

INFERENCE
根据事实推演得到的信息

DESIGN_DECISION
经过设计判断后形成的方案

LOCKED
已经确认并锁定的设计
```

禁止将AI推演内容伪装成用户原始事实。

Master已经锁定的事实不得被本Skill修改。

---

# 6. 固定执行流程

## STEP 01｜读取上下文

读取：

- Master项目上下文
- 用户补充信息
- 已有IP
- 参考资产
- 已锁定信息
- 当前版本

不得重复询问Master已经提供的信息。

---

## STEP 02｜事实分析

提取：

- IP名称
- 地区
- 项目
- 行业
- 项目理念
- 服务对象
- 使用场景
- 用户明确要求
- 禁止事项
- 已有IP特征

建立事实集合：

```yaml
FACT_SET:
  explicit:
  inferred:
  constraints:
```

---

## STEP 03｜原始IP分析

分析已有IP：

- 物种/主体
- 核心轮廓
- 头身比例
- 脸部
- 身体
- 服装
- 配饰
- 颜色
- 已有视觉语言
- 已有记忆点
- 独特结构

形成：

```yaml
EXISTING_IP_ANCHOR:
  species:
  silhouette:
  proportion:
  face:
  body:
  costume:
  accessories:
  color:
  signature_features:
```

原则：

> 已有IP的核心识别特征优先于新发散设计。

---

# 7. 人物身份推演

根据：

```text
地区
+
项目
+
行业
+
理念
+
服务对象
+
应用场景
+
已有IP特征
```

推演：

- 角色身份
- 角色定位
- 核心职责
- 角色使命
- 社会角色

例如：

```text
工伤预防
+
劳动者
+
公益
+
守护
↓
劳动者守护者
```

---

# 8. 人物基础属性推演

自动形成：

- 性别
- 年龄阶段
- 性格
- 气质
- 行为倾向
- 角色关系

## 年龄规则

优先使用年龄阶段，而不是无依据生成具体数字：

- 幼年
- 少年
- 青年
- 成年
- 成熟
- 长者
- 超现实/无明确年龄

只有项目已有明确年龄时才输出具体数字。

---

# 9. 性格推演

采用三层结构：

```yaml
PERSONALITY:
  core:
  support:
  behavior:
```

页面只显示3–5个核心关键词。

例如：

```text
可靠 · 阳光 · 亲和 · 专业
```

不得生成冗长心理画像。

---

# 10. 视觉性格推演

将心理属性转化为视觉属性：

```text
性格
↓
视觉气质
↓
形态语言
↓
人物表现
```

例如：

```text
可靠
→ 稳定

亲和
→ 开放

专业
→ 简洁、有秩序

力量
→ 稳定重心、明确轮廓
```

输出：

```yaml
VISUAL_PERSONALITY:
  keywords:
  silhouette_language:
  posture_language:
  facial_language:
```

---

# 11. IP亮点设计

## 11.1 定义

IP亮点设计不是简单寻找地域元素，而是：

> 从地域、文化、产业、行业、项目理念、物种特征和已有IP视觉中主动发现具有识别价值的设计机会，并将其转译成具体、可执行、可延展的视觉亮点。

---

## 11.2 亮点来源池

```text
地域
文化
产业
行业
项目理念
物种特征
已有IP视觉
```

---

## 11.3 候选亮点

先建立候选池，不直接决定：

```yaml
IP_HIGHLIGHT_CANDIDATES:
  - element:
    source:
    reason:
```

允许AI内部发散多个可能性。

---

## 11.4 亮点评估

每个候选亮点判断：

- 地域关联度
- 项目关联度
- 行业关联度
- 视觉转译能力
- IP融合度
- 识别度
- 差异性
- 延展性

评估用于筛选与解释，不强制生成简单数字评分。

---

# 12. 亮点视觉转译

每个最终亮点必须回答：

```text
元素是什么？
↓
为什么适合？
↓
如何转译？
↓
进入IP哪个部位/系统？
↓
形成什么记忆？
```

例如：

```text
大枣
↓
圆润果实形态
↓
结构转译
↓
安全帽顶部
↓
地域 + 行业双重记忆点
```

最终形成：

> 大枣 × 安全帽

---

# 13. 亮点转译方式

可采用：

```text
形态转译
结构转译
色彩转译
纹样转译
符号转译
功能转译
叙事转译
```

不得为了加入元素而破坏人物主体结构。

---

# 14. 亮点分级

最终亮点分为：

```text
CORE
核心亮点

SUPPORT
辅助亮点

EXTENSION
延展亮点
```

### CORE

决定IP识别度。

### SUPPORT

丰富人物视觉。

### EXTENSION

用于未来：

- 服装
- 海报
- 文创
- 辅助图形
- 场景
- 宣传物料

---

# 15. 亮点数量

页面默认：

```text
核心亮点：1–2个
辅助亮点：1–2个
```

AI内部可以发现更多候选，但不得全部展示。

原则：

> 有亮点，而不是堆亮点。

---

# 16. 人物结构推演

形成：

```yaml
CHARACTER_STRUCTURE:
  head_body_ratio:
  body_proportion:
  head_structure:
  limb_structure:
  center_of_gravity:
  silhouette:
  posture:
  movement_language:
```

原则：

> 不为了新的角色设定而破坏已有IP核心结构。

---

# 17. 核心记忆点

最终提炼1–3个：

```yaml
SIGNATURE_FEATURES:
  - character_feature
  - regional_feature
  - industry_feature
```

优先级：

```text
已有IP核心特征
>
核心亮点
>
辅助视觉特征
```

---

# 18. 人物故事

人物故事只需要建立角色的：

```text
来源
+
身份
+
使命
```

输出1–2句。

例如：

> 来自第三师的劳动者守护伙伴，用熟悉的地域元素传递安全与关怀。

禁止生成长篇人物小传。

---

# 19. Character Spec

最终形成：

```yaml
CHARACTER_SPEC:
  identity:
    name:
    role:
    region:

  basic:
    gender:
    age_stage:
    personality:

  story:
    mission:
    short_story:

  visual:
    visual_personality:
    proportion:
    silhouette:
    face:
    body:

  highlight:
    core:
    support:
    extension:

  signature:
    key_features:

  constraints:
    forbidden:
```

---

# 20. IP Highlight Spec

```yaml
IP_HIGHLIGHT_SPEC:
  core:
    - name:
      source:
      element:
      relationship:
      translation_method:
      visual_form:
      target_location:
      memory_value:
      extensibility:

  support:
    - name:
      source:
      translation_method:

  extension:
    - name:
      source:
      possible_application:
```

---

# 21. Character DNA

```yaml
CHARACTER_DNA:

  identity:
    name:
    role:
    region:

  story:
    mission:
    narrative:

  personality:
    core:
    support:
    behavior:

  visual:
    personality:
    silhouette:
    proportion:
    structure:

  highlight:
    core:
    support:
    extension:

  signature_features:

  forbidden_design:
```

---

# 22. Character Lock

## HARD LOCK

```text
IP名称
角色身份
物种
核心轮廓
核心人物结构
核心记忆点
核心亮点
核心设计逻辑
```

## SOFT LOCK

```text
表情
姿态
动作
服装延展
配饰
职业状态
场景状态
```

## VARIABLE

```text
镜头
场景
主题
动作
情绪
道具
宣传内容
```

下游Skill只能修改允许修改的层级。

---

# 23. 页面设计规范

## 23.1 固定尺寸

**16:9横版。**

## 23.2 页面定位

不是人物资料表，而是：

> 视觉化IP人物设定页。

## 23.3 页面核心内容

```text
IP归属
人物身份
基础人物信息
人物故事
IP亮点
视觉特征
```

---

# 24. 页面信息密度

必须：

- 少文字
- 短句
- 关键词
- 视觉优先
- 亮点优先

基础信息只需要：

```text
性别
年龄阶段
性格关键词
角色定位
```

人物故事：

> 1–2句

IP亮点：

> 名称 + 一句话解释

例如：

```text
大枣 × 安全帽
地域特色 → 头部记忆点
```

---

# 25. 页面视觉层级

```text
01 IP主形象
02 核心亮点
03 IP名称 / 归属
04 人物身份
05 性格 / 年龄 / 性别
06 简短故事
07 视觉关键词
```

禁止：

- 大段文字
- 长篇说明
- AI推理过程
- 复杂参数表
- 大量候选元素
- 信息堆叠
- 重复描述
- 无意义的信息填充

后台可以复杂。

前台必须简洁。

---

# 26. 自动质量检查

完成后必须检查：

## Identity Check

是否明确：

- IP是谁
- 来自哪里
- 为什么存在

## Character Check

是否形成：

- 性别
- 年龄阶段
- 性格
- 身份

## Highlight Check

是否存在：

- 核心亮点
- 亮点来源
- 视觉转译逻辑

## Visual Check

是否形成：

- 视觉性格
- 人物结构
- 核心记忆点

## Consistency Check

是否与：

- Master项目事实
- 原始IP
- 已锁定设计

一致。

## Page Check

是否：

- 16:9
- 文字精简
- 视觉优先
- 亮点明确
- 无长篇说明

若不通过，自动修正后再输出。

---

# 27. 冲突处理

## 资料冲突

进入：

```text
CONFLICT
→ NEED_USER_CONFIRMATION
```

仅询问冲突事实。

## 设计判断不确定

继续完成。

内部标记：

```text
CONFIDENCE:
HIGH / MEDIUM / LOW
```

不得因为普通设计不确定性而中断工作流。

---

# 28. Runtime Observability

每次运行记录：

```yaml
RUNTIME_OBSERVABILITY:
  skill:
    name: ip-character-definition
    version: 1.0

  trigger:
    source:
    reason:


<!-- END SOURCE: skills/ip-character-definition/SKILL.md -->
