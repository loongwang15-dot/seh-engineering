# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-POSTER.md | bytes=9111 | chars=8709 | sha256=44e54dfc9f29aeb40a993f358a8fc56d941d5c3444d545d8570fa00af34bf919 -->

---
name: ip-poster-design-skill
description: "IP 提案海报设计 Skill（IP Poster Design Skill v1.0）：基于已锁定的 IP 资产与职业服装资产，生成提案级 IP 应用海报，展示 IP 视觉价值、职业身份、场景适应性与系列设计能力。属于 IP Design OS 延展工作流。不是最终行业宣传海报生成器。触发：IP 提案海报、应用海报、系列海报、场景海报、IP+职业服装海报、已有 IP 的视觉展示海报。禁止作为主 Skill 处理：IP 创建、IP 重设计、角色三视图、职业服装设计、表情设计、条漫设计、行业最终宣传海报、纯排版设计、文字修正任务。"
type: Production Skill
version: v1.0
---

# IP Poster Design Skill v1.0

## Skill Identity

**Skill Name:** IP Poster Design Skill\
**File:** SKILL.md\
**Purpose:** Generate IP proposal posters based on locked IP assets and
professional clothing extension assets.

This Skill belongs to the IP Design OS extension workflow.

Core positioning:

> Create proposal-level IP application posters that demonstrate IP
> visual value, occupational identity, scenario adaptability, and series
> design capability.

This Skill is NOT a final industry communication poster generator.

------------------------------------------------------------------------

# Trigger Rules

Activate when users request:

-   IP proposal posters
-   IP application posters
-   IP series posters
-   IP scenario posters
-   IP + professional clothing posters
-   visual presentation posters for an existing IP

------------------------------------------------------------------------

# Non Trigger Rules

Do not execute as primary Skill for:

-   IP character creation
-   IP redesign
-   character turnaround sheets
-   professional clothing design
-   emoji design
-   comic design
-   industry-specific final publicity posters
-   typography-only design
-   text correction tasks

These must route to their corresponding Skills.

------------------------------------------------------------------------

# Input Interface

Required:

-   IP identity
-   IP reference assets
-   IP visual DNA
-   locked style information
-   professional clothing asset
-   poster quantity
-   poster theme

Optional:

-   project name
-   existing titles
-   references
-   dimensions
-   special requirements

------------------------------------------------------------------------

# Workflow Lock

Before generation:

## IP Asset Lock

Lock:

-   character appearance
-   proportions
-   colors
-   core features
-   visual style

## Clothing Asset Lock

Lock:

-   professional identity
-   clothing structure
-   protective equipment
-   materials
-   industry adaptation

Poster generation cannot modify locked assets.

------------------------------------------------------------------------

# Core Workflow

    Pre-Analyzed Design Packet Validation
    ↓
    Asset Lock
    ↓
    Content Matrix Planning
    ↓
    Visual Matrix Planning
    ↓
    Cross Project Similarity Check
    ↓
    Poster Generation
    ↓
    Visual QA
    ↓
    Text Layout
    ↓
    Text QA
    ↓
    Series QA
    ↓
    Final Project QA
    ↓
    Asset Commit
    ↓
    Final Output

------------------------------------------------------------------------

# Content Matrix

The external analysis layer defines the following before Lovart execution. Lovart validates the fields but does not independently re-analyze the source project.

Before visual generation, define:

-   poster role
-   communication purpose
-   title direction
-   visual expression

Example structure:

1.  IP Value Presentation
2.  Professional Identity Presentation
3.  Scenario Application
4.  Communication Application

This is a flexible strategy, not a fixed template.

------------------------------------------------------------------------

# Text Rules

Default text structure:

-   Main Title
-   Subtitle

Rules:

-   No long paragraphs
-   No unnecessary copy
-   No random generated text

Recommended:

Main title: 4-10 characters

Subtitle: 6-18 characters

Text visual area:

8%-15% of poster composition.

Priority:

IP and visual scene \> title \> subtitle

------------------------------------------------------------------------

# Visual Design Rules

Poster composition should include:

-   IP subject
-   professional clothing
-   environment
-   foreground
-   middle ground
-   background
-   industry elements
-   visual movement

Do not add meaningless decorative elements.

Forbidden:

-   random equipment
-   random signs
-   random buildings
-   random text
-   unrelated effects

------------------------------------------------------------------------

# Series Differentiation

Each poster in one project must vary:

-   composition
-   camera angle
-   character position
-   character action
-   scene
-   visual focus
-   title placement
-   spatial relationship

Avoid repeated combinations.

------------------------------------------------------------------------

# Cross Project Differentiation

Each completed project creates:

## Project Poster DNA

Contains:

-   composition DNA
-   color DNA
-   scene DNA
-   character expression DNA
-   title DNA
-   lighting DNA

## Design Fingerprint

Records:

-   composition
-   camera
-   character position
-   character action
-   scene
-   title layout
-   visual focus
-   lighting
-   image/text relationship

New projects must compare against previous records.

------------------------------------------------------------------------

# QA System

## IP QA

Check:

-   appearance consistency
-   proportions
-   features
-   colors
-   style

## Clothing QA

Check:

-   clothing accuracy
-   protective equipment
-   professional suitability
-   completeness

## Content QA

Check:

-   theme accuracy
-   title accuracy
-   visual meaning consistency

## Text QA

Check:

-   missing strokes
-   wrong characters
-   distorted text
-   readability

## Visual QA

Check:

-   composition
-   hierarchy
-   richness
-   IP visibility
-   scene logic

## Series QA

Check:

-   internal repetition
-   composition repetition
-   action repetition
-   viewpoint repetition

## Cross Project QA

Check against historical Poster DNA and Design Fingerprints.

------------------------------------------------------------------------

# Error Recovery

Failures must return only to the failed module.

Examples:

TEXT_QA_FAILED → Text Layout

VISUAL_QA_FAILED → Visual Generation

SERIES_VARIATION_FAILED → Visual Matrix

CLOTHING_QA_FAILED → Clothing Asset

IP_QA_FAILED → IP Asset

CROSS_PROJECT_HIGH → Visual Planning

Do not restart the whole workflow unnecessarily.

------------------------------------------------------------------------

# State Machine

    INIT
    REQUIREMENT_ANALYSIS
    ASSET_LOCK
    CONTENT_MATRIX
    VISUAL_MATRIX
    CROSS_PROJECT_CHECK
    VISUAL_GENERATION
    VISUAL_QA
    TEXT_LAYOUT
    TEXT_QA
    SERIES_QA
    FINAL_PROJECT_QA
    ASSET_COMMIT
    FINAL

------------------------------------------------------------------------

# Asset Register

After final approval:

    FINAL_PROJECT_QA = PASS
            ↓
    ASSET_COMMIT

Register:

-   Project ID
-   Poster DNA
-   Design Fingerprint
-   Content Matrix
-   Visual Matrix
-   QA Record
-   Version
-   Usage Frequency
-   Final Poster Assets

------------------------------------------------------------------------

# Asset Library Interface

Structure:

    Poster Asset Library

    Project DNA
    Design Fingerprints
    Content Matrix
    Visual Matrix
    QA Records
    Usage Frequency

Future projects read this library before generation.

------------------------------------------------------------------------

# Runtime Observability

Record:

-   Skill_ID
-   Project_ID
-   Current_State
-   IP_Asset_Version
-   Clothing_Asset_Version
-   Content_Matrix_Version
-   Poster_DNA
-   Design_Fingerprint
-   QA_Status
-   Retry_Count
-   Failure_Type
-   Asset_Commit_Status

------------------------------------------------------------------------

# Downstream Interface

Outputs:

User Output:

-   poster series
-   title structure
-   subtitle structure

System Output:

-   Content Matrix
-   Visual Matrix
-   Poster DNA
-   Design Fingerprint
-   QA Record
-   Asset Commit Record

------------------------------------------------------------------------

# Forbidden Actions

The Skill must not:

-   redesign locked IP
-   modify locked clothing assets
-   add unauthorized logos
-   add unauthorized text
-   generate long copy
-   ignore QA
-   commit failed assets
-   use fixed templates repeatedly
-   sacrifice IP consistency for visual variation

------------------------------------------------------------------------

# Completion Criteria

A project is complete only when:

-   IP consistency passed
-   clothing consistency passed
-   content passed
-   text passed
-   visual quality passed
-   series differentiation passed
-   cross-project check passed
-   Poster DNA created
-   Design Fingerprint created
-   Asset Commit completed

Final state:

`FINAL / ASSET_COMMITTED`

------------------------------------------------------------------------

# Version Control

Current Version:

`IP_Poster_Design_Skill v1.0`


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-POSTER.md -->


------------------------------------------------------------------------

# Lovart Pre-Analyzed Execution Addendum

## Execution Boundary

This Poster Skill is an execution skill, not a long-document analysis skill.

It MUST NOT:
- analyze the full source archive;
- infer a new campaign strategy from raw documents;
- rewrite confirmed poster copy;
- reinterpret locked visual decisions;
- restart the project because a source PDF/TXT/MD is attached.

It MUST:
- consume the supplied Pre-Analyzed Design Packet;
- lock the supplied IP and clothing assets;
- execute the supplied content and visual matrix;
- perform poster generation;
- perform the defined Visual QA, Text QA, Series QA and Final Project QA;
- make only local revisions required by failed QA.

## Required Packet Fields

```text
PROJECT_ID
PRIMARY_DELIVERABLE = POSTER
POSTER_QUANTITY
DIMENSIONS
CORE_THEME
CONFIRMED_COPY
IP_ASSET + VERSION
CLOTHING_ASSET + VERSION
LOCKED_VISUAL_DNA
SCENE_REQUIREMENTS
COMPOSITION_REQUIREMENTS
TEXT_HIERARCHY
SERIES_VARIATION_REQUIREMENTS
QA_REQUIREMENTS
DO_NOT_CHANGE
FINAL_DELIVERY_FORMAT
```

## Packet-First Workflow

```text
PACKET_VALIDATION
↓
ASSET_LOCK
↓
CONTENT_MATRIX
↓
VISUAL_MATRIX
↓
CROSS_PROJECT_CHECK
↓
POSTER_GENERATION
↓
VISUAL_QA
↓
TEXT_LAYOUT
↓
TEXT_QA
↓
SERIES_QA
↓
FINAL_PROJECT_QA
↓
ASSET_COMMIT
↓
FINAL
```

No open-ended requirement analysis is performed inside this Skill.

## Silent Action Test

After generation, ignore text, sound and mouth movement. Inspect only action, expression, environment, hazard source and spatial relationships.

Question:

> Without reading the text, can the viewer still broadly understand the safety situation?

If not, revise the visual narrative first. Do not compensate for an unclear scene by adding more copy.

## Local Revision Rule

If QA fails:
- TEXT_QA_FAILED → Text Layout
- VISUAL_QA_FAILED → Poster Generation
- SERIES_VARIATION_FAILED → Visual Matrix
- CLOTHING_QA_FAILED → Asset Lock / Clothing Asset
- IP_QA_FAILED → Asset Lock / IP Asset
- CROSS_PROJECT_HIGH → Visual Matrix

Do not restart the complete project unless the locked design brief itself has changed.
