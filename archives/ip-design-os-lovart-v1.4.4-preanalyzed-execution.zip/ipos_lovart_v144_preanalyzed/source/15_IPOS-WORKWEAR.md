# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-WORKWEAR.md | bytes=10146 | chars=9660 | sha256=bb52234b93661fb97aa2708667c4115ca418dc8888724d2e244ad01936770c23 -->

---
name: occupational-clothing-asset-skill
description: "IP 职业服装资产设计 Skill（Occupational Clothing Asset Skill）：为已有 IP 角色生成受控的职业服装/PPE/装备资产节点，供海报、条漫、物料延展、汇报等下游流程复用。核心管线：IP Asset → 职业适配 → 服装/PPE/装备设计 → QA → 用户确认 → 版本锁定 → 下游使用。必须保留 IP DNA 与亮点 DNA（含亮点载体关系），职业标准须取自外部职业安全资源，不得臆造安全标准。触发：IP 职业服装设计、行业服装延展、工装适配、防护服设计、职业角色转化、行业 IP 版本创建、PPE 整合角色设计。禁止用于：通用时尚设计、节日服装、海报构图、条漫创作、纯场景设计、独立 PPE 设计。"
type: Production Skill
version: V1.0
---

# IP职业服装资产设计 Skill

## Occupational Clothing Asset Skill

## Skill Positioning

This Skill creates controlled occupational clothing assets for existing
IP characters. It is not a simple image generation module. It creates a
reusable asset node for downstream poster, comic, material extension,
and presentation workflows.

Core pipeline:

IP Asset → Occupational Adaptation → Clothing/PPE/Equipment Design → QA
→ User Confirmation → Version Lock → Downstream Use

------------------------------------------------------------------------

# Trigger Rules

Activate when users request:

-   IP occupational clothing design
-   Industry clothing extension
-   Workwear adaptation
-   Protective clothing design
-   Professional role transformation
-   Industry IP version creation
-   PPE-integrated character design

------------------------------------------------------------------------

# Non Trigger Rules

Do not activate for:

-   General fashion design
-   Festival costumes
-   Poster composition
-   Comic creation
-   Scene design only
-   Independent PPE design

------------------------------------------------------------------------

# Core Asset Rules

## IP DNA Lock

The Skill must not modify:

-   Character identity
-   Face features
-   Body proportion
-   Core visual identity
-   Original IP DNA

## Highlight DNA Lock

Original IP highlights are reference-locked assets.

The Skill may decide adaptation strategy but cannot redefine original
highlights.

------------------------------------------------------------------------

# Highlight Carrier Rules

Every highlight must contain:

-   highlight_id
-   name
-   original_carrier
-   position
-   meaning
-   priority
-   migration_rule

Priority:

## P0 Core Asset

Must preserve.

## P1 Carrier Bound Highlight

Must preserve original carrier relationship.

Example: A Yi ethnic sleeve pattern belongs to the original sleeve. It
cannot automatically migrate onto protective clothing.

## P2 Visual Language

May reference:

-   color
-   rhythm
-   material language
-   visual style

## P3 Decoration

May be adjusted.

------------------------------------------------------------------------

# Occupational Adaptation Level

## Level 0

Original clothing maintained.

## Level 1

Partial occupational enhancement.

## Level 2

Structural clothing adjustment.

## Level 3

Functional reconstruction.

Functional reconstruction does not mean copying all original decorations
into new clothing.

------------------------------------------------------------------------

# Professional Standard Interface

Professional standards must be retrieved from external occupational
safety resources.

Priority:

1.  Mandatory safety requirements
2.  Professional protective requirements
3.  Industry recognition
4.  Industry convention
5.  Decoration

------------------------------------------------------------------------

# Clothing Structure

The output must separate:

## Clothing

-   Workwear
-   Protective clothing
-   Uniform structure

## PPE

-   Helmet
-   Safety belt
-   Protective equipment

## Equipment

-   Tools
-   Professional devices

------------------------------------------------------------------------

# Workflow

1.  Load IP Asset
2.  Lock IP DNA
3.  Read Highlight DNA
4.  Load Industry Requirements
5.  Determine Occupational Level
6.  Build Clothing/PPE/Equipment Plan
7.  Resolve Highlight Carrier Relationship
8.  Generate Occupational Clothing Asset
9.  Run Occupational Clothing QA
10. Wait for User Confirmation
11. Create Version
12. Lock Asset
13. Expose Downstream Interface

------------------------------------------------------------------------

# Highlight Adaptation States

## PRESERVED

Original carrier remains.

## REFERENCED

Only visual language is used.

## NOT_APPLIED

No suitable carrier exists. Absence is acceptable.

## VIOLATION

Incorrect migration or modification.

------------------------------------------------------------------------

# Output Interface

Output asset contains:

-   Asset ID
-   Version
-   Industry
-   Occupation
-   Clothing structure
-   PPE structure
-   Equipment structure
-   Highlight adaptation records
-   QA status
-   User confirmation status
-   Lock status

------------------------------------------------------------------------

# Visual Output Rules

Canvas:

16:9

Default:

-   Full body IP display
-   Minimal text
-   Adaptive background
-   No mandatory scene design

Background:

-   Solid color
-   Gradient
-   Minimal abstract environment

Text:

Only:

-   Industry name
-   Occupation name

------------------------------------------------------------------------

# Occupational Clothing QA

QA is mandatory.

## Clothing Integrity

Check:

-   Complete clothing structure
-   Correct garment connection
-   Complete sleeves and pants
-   Correct footwear
-   No deformation
-   No broken structures

## PPE Compliance

Check:

-   Required PPE exists
-   Correct PPE type
-   Correct wearing position
-   Professional logic
-   No decorative PPE substitution

## Highlight Compatibility

Check:

-   Original carrier relationship
-   Incorrect migration
-   Highlight semantic change

## IP Consistency

Check:

-   Character identity
-   Core colors
-   Core silhouette
-   Visual style

## Occupational Fit

Check:

-   Industry relevance
-   Professional logic
-   Equipment compatibility

## Text QA

Check:

-   Missing characters
-   Wrong text
-   Font errors
-   Rendering defects

------------------------------------------------------------------------

# Workflow Lock

Generation cannot proceed downstream until:

QA PASS

AND

User Confirmation

------------------------------------------------------------------------

# User Confirmation Gate

After QA PASS:

Status:

WAITING_USER_CONFIRMATION

The user must approve before downstream usage.

------------------------------------------------------------------------

# Modification Rules

User modifications create a new occupational clothing version.

Default scope:

occupational_clothing_only

Modification does not affect:

-   IP DNA
-   Highlight DNA
-   Original IP asset

------------------------------------------------------------------------

# Highlight Conflict Warning

If user modification affects highlights:

The system must warn:

This change affects an original IP highlight carrier relationship. If
continued, the modification applies only to the occupational clothing
version and does not update the original IP definition.

After confirmation:

Create new clothing version.

Do not write back to IP.

------------------------------------------------------------------------

# State Machine

IDLE

↓

TRIGGERED

↓

INPUT_VALIDATION

↓

IP_ASSET_LOCKED

↓

RESOURCE_QUERY

↓

DESIGN_PLAN_READY

↓

GENERATING

↓

QA_RUNNING

↓

PASS / FAIL

↓

USER_CONFIRMATION

↓

VERSION_CREATE

↓

ASSET_LOCKED

↓

DOWNSTREAM_READY

------------------------------------------------------------------------

# Error Recovery

## Generation Error

Retry generation while preserving:

-   IP DNA
-   Highlight DNA
-   Occupational requirements

## QA Failure

Attempt automatic correction.

If unresolved:

Return for review.

## Highlight Conflict

Pause modification and request confirmation.

------------------------------------------------------------------------

# Asset Register

Asset:

OCCUPATIONAL_CLOTHING_ASSET

Required fields:

-   asset_id
-   version
-   status
-   industry
-   occupation
-   clothing
-   PPE
-   equipment
-   highlight_mapping
-   QA_result
-   confirmation_state

------------------------------------------------------------------------

# Version Control

Format:

OCC-CLOTHING-V1

OCC-CLOTHING-V2

Each modification creates a new version.

Previous versions remain preserved.

------------------------------------------------------------------------

# Runtime Observability

Record:

-   Trigger reason
-   Input validation
-   IP loading
-   Resource calls
-   Occupational level
-   Highlight decisions
-   Generation attempts
-   QA results
-   User confirmation
-   Version creation
-   Lock status

------------------------------------------------------------------------

# Downstream Interface

Only:

OCCUPATIONAL_CLOTHING_LOCKED

assets may be used by:

-   Poster Skill
-   Comic Skill
-   Material Extension Skill
-   Scene Skill

Downstream Skills may:

-   Use
-   Combine
-   Layout

They may not:

-   Redesign clothing
-   Change PPE
-   Modify highlights

------------------------------------------------------------------------

# Forbidden Actions

Never:

-   Modify IP DNA
-   Rewrite highlight definitions
-   Force highlight migration
-   Invent safety standards
-   Remove required PPE
-   Replace professional equipment with decoration
-   Skip QA
-   Skip user confirmation
-   Overwrite locked assets
-   Allow downstream redesign

------------------------------------------------------------------------

# Completion Criteria

A task is complete only when:

1.  IP asset loaded
2.  Occupational requirements confirmed
3.  Clothing design completed
4.  PPE checked
5.  Highlight compatibility resolved
6.  QA passed
7.  User confirmed
8.  Version created
9.  Asset locked
10. Downstream interface generated


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-WORKWEAR.md -->
