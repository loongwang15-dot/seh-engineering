# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-THREEVIEW.md | bytes=6075 | chars=3917 | sha256=83c522e18464eb627e1bf3a361a5b60cf4dbe7ee0105536f1e7b6a4cde91145c -->

---
name: ip-three-view-extension
description: "基于已确定的 IP 形象生成标准化三视图延展（FRONT/SIDE/BACK），保持 IP 身份、角色比例、身体结构、面部特征、服装造型、色彩体系、配饰、特殊结构、姿势逻辑与视觉风格一致。核心原则：只延展不改造，只统一不重设计。触发：用户要求生成 IP 三视图、正面/侧面/背面、角色转面图，上传 IP 并要求制作标准三视图，或要求根据现有 IP 延展视角。禁止接管：IP 重新设计、视觉设计规范、新服装设计与其他资产生成（表情包/海报/场景/条漫/动态表情/商业物料）。"
version: 1.0.0
status: production-ready
category: IP Design OS Child Skill
layer: IP Asset Standardization
---

# IP Three-View Extension Skill

## Skill定位

本 Skill 负责根据用户提供的已确定 IP 形象，进行标准化三视图延展绘画。

核心目标：

将单一 IP 形象转换为：

- FRONT（正面）
- SIDE（侧面）
- BACK（背面）

三个统一视角，并保持：

- IP身份
- 角色比例
- 身体结构
- 面部特征
- 服装造型
- 色彩体系
- 配饰
- 特殊结构
- 姿势逻辑
- 视觉风格

的一致性。

核心原则：

> 只延展，不改造；只统一，不重设计。

---

# Trigger Rules

当满足以下条件时触发：

- 用户要求生成 IP 三视图
- 用户要求正面、侧面、背面
- 用户要求角色转面图
- 用户上传 IP 并要求制作标准三视图
- 用户要求根据现有 IP 延展视角

最低输入要求：

1. 已存在 IP 参考形象；
2. 用户明确要求三视图延展。

---

# Non Trigger Rules

以下情况禁止本 Skill 接管：

## IP重新设计

包括：

- 改变角色身份
- 重新设计脸型
- 改变身体比例
- 改变视觉定位

## 视觉设计规范

包括：

- 创建新风格
- 修改视觉语言
- 建立品牌视觉系统

## 新服装设计

包括：

- 新服装方案
- 服装改造
- 主题换装

本 Skill 只展示已有服装。

## 其他资产生成

包括：

- 表情包
- 海报
- 场景
- 条漫
- 动态表情
- 商业物料

---

# Input Interface

## Required Input

```yaml
IP_REFERENCE:
  type: image
  required: true
  description: 已确定 IP 原始形象
```

## Optional Input

```yaml
IP_NAME:
GENDER:
AGE:
PERSONALITY:
STYLE_REFERENCE:
COSTUME_REFERENCE:
COLOR_REFERENCE:
LAYOUT_REFERENCE:
USER_REQUIREMENT:
```

---

# Reference Priority

参考资料优先级：

```
IDENTITY_REFERENCE
        ↓
STYLE_REFERENCE
        ↓
COSTUME_REFERENCE
        ↓
COLOR_REFERENCE
        ↓
LAYOUT_REFERENCE
```

Identity Reference 永远最高优先级。

---

# Workflow

## Stage 01 Input Analysis

读取：

- IP参考图
- 用户需求
- 已有设计约束

---

## Stage 02 Identity Lock

建立：

```yaml
identity_lock:
 character:
 body_ratio:
 face:
 hairstyle:
 costume:
 colors:
 accessories:
 silhouette:
 distinctive_features:
 style:
```

锁定：

- 身份
- 比例
- 服装
- 色彩
- 特征元素

---

## Stage 03 Three View Generation

生成：

```
FRONT
SIDE
BACK
```

要求：

三个视角必须属于同一个角色。

---

## Stage 04 Consistency Validation

检查：

- 身份一致
- 比例一致
- 服装一致
- 色彩一致
- 配饰一致
- 姿势一致
- 风格一致

---

## Stage 05 Correction

错误时执行：

Targeted Correction

只修复错误区域。

禁止无必要重新生成整个角色。

---

## Stage 06 Review Gate

状态：

```
REVIEW
```

等待用户确认。

---

## Stage 07 Lock

用户确认后：

```
THREE_VIEW_LOCK = TRUE
```

写入资产系统。

---

# State Machine

```
IDLE
 ↓
INPUT_RECEIVED
 ↓
IDENTITY_ANALYZING
 ↓
IDENTITY_LOCKED
 ↓
GENERATING
 ↓
VALIDATING
 ↓
CORRECTING
 ↓
REVIEW
 ↓
APPROVED
 ↓
LOCKED
```

异常：

```
FAILED
```

---

# Workflow Lock

锁定内容：

- IP身份
- 身体比例
- 服装结构
- 色彩
- 配饰
- 特征元素
- 三视图关系

三视图锁定后：

下游 Skill 不得修改角色基础结构。

---

# QA检查机制

检查矩阵：

|项目|要求|
|-|-|
|IP身份|一致|
|头身比例|一致|
|身体结构|一致|
|服装|一致|
|服装结构|一致|
|颜色|一致|
|配饰|一致|
|特殊结构|一致|
|姿势|一致|
|视觉风格|一致|

---

# Error Recovery

错误优先级：

```
P0 身份错误
P1 比例错误
P2 服装错误
P3 配饰错误
P4 色彩错误
P5 细节错误
P6 排版错误
```

恢复策略：

- 局部修正
- 定向修复
- 保留 Identity Lock

---

# Asset Register

输出资产：

```yaml
asset:
 type: three_view_sheet
 views:
  - front
  - side
  - back

 lock:
  identity_lock:
  three_view_lock:
```

---

# Version Control

当前版本：

```
Version: 1.0.0
Status: Production Ready
```

版本规则：

- 新增能力：Minor Version
- 修改核心逻辑：Major Version
- Bug修复：Patch Version

---

# Runtime Observability

运行状态：

```yaml
runtime:
 skill:
 version:
 state:
 progress:
 current_stage:
 retry_count:
 validation_status:
 identity_lock:
 three_view_lock:
 user_confirmation:
 error_code:
```

---

# Downstream Interface

输出给：

- IP Master
- 表情包 Skill
- 场景 Skill
- 海报 Skill
- 条漫 Skill
- 动态表情 Skill

输出：

```yaml
three_view_asset:
 front_view:
 side_view:
 back_view:
 consistency_report:
 three_view_lock:
```

---

# Forbidden Actions

禁止：

1. 修改已有IP身份；
2. 修改身体比例；
3. 修改服装设计；
4. 修改颜色系统；
5. 删除重要配饰；
6. 添加无依据元素；
7. 改变年龄感；
8. 改变性别特征；
9. 创建不同角色；
10. 未确认直接锁定资产。

---

# Completion Criteria

完成标准：

```
✓ 三个视角属于同一IP
✓ 正侧背结构合理
✓ 身体比例一致
✓ 服装一致
✓ 色彩一致
✓ 配饰一致
✓ 姿势一致
✓ 风格一致
✓ QA通过
✓ 用户确认完成
✓ THREE_VIEW_LOCK建立
```

最终状态：

```
THREE_VIEW_STATUS = APPROVED
THREE_VIEW_LOCK = TRUE
```


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-THREEVIEW.md -->
