# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-COLOR.md | bytes=6046 | chars=4426 | sha256=5aace6469904bf43ef9321e7968d4c010aa0e67f5f16352bca0152939aaa6a42 -->

---
name: color-system
description: "IP 色彩规范与颜色调用控制 Production Skill：为已确定 IP 建立轻量化、程序优先、可调用、可锁定、可验证的 Color System。核心职责：识别 IP 核心颜色、建立 Color Role、输出 Color Token、定义颜色优先级与比例、管理 Workflow Lock、提供下游统一颜色接口、执行色彩一致性 QA。触发：提取 IP 配色、建立 IP 色彩规范、输出主色/辅助色/强调色/中性色与色值、建立颜色调用规则、锁定 IP 核心颜色、IP 工作流需要建立 Color System。禁止作为以下任务入口：IP 生成、三视图、服装、海报、条漫、表情包、场景、字体、整体视觉风格设计；只管理颜色规则，不决定视觉方向。"
version: 1.0.0
---

# Color System Skill

## Skill定位

负责为已确定 IP 建立轻量化、程序优先、可调用、可锁定、可验证的 Color
System。

核心职责： - 识别 IP 核心颜色 - 建立 Color Role - 输出 Color Token -
定义颜色优先级与比例 - 管理 Workflow Lock - 提供下游统一颜色接口 -
执行色彩一致性 QA

本 Skill 不负责 IP 创意设计、视觉风格设计、构图设计或物料设计。

------------------------------------------------------------------------

# Trigger Rules

触发条件：

-   提取 IP 配色
-   建立 IP 色彩规范
-   输出主色/辅助色/强调色/中性色
-   输出色值
-   建立颜色调用规则
-   锁定 IP 核心颜色
-   IP 工作流需要建立 Color System

------------------------------------------------------------------------

# Non Trigger Rules

禁止作为以下任务入口：

-   IP生成
-   三视图设计
-   服装设计
-   海报设计
-   条漫设计
-   表情包设计
-   场景设计
-   字体设计
-   整体视觉风格设计

职责边界：

只管理颜色规则，不决定视觉方向。

------------------------------------------------------------------------

# Input Interface

Required:

-   IP Reference Image

Optional:

-   IP DNA
-   IP Name
-   Existing Color System
-   Brand Color
-   Logo
-   Previous Version

Input Status:

-   COMPLETE
-   PARTIAL
-   INSUFFICIENT

INSUFFICIENT 状态禁止自动创造核心颜色。

------------------------------------------------------------------------

# Workflow

## Step 1 Input Analysis

读取 IP 资产。

## Step 2 Color Analysis

识别：

-   主体颜色
-   服装颜色
-   配件颜色
-   标志性色彩
-   中性色

## Step 3 Role Assignment

建立：

1.  PRIMARY
2.  SECONDARY
3.  ACCENT
4.  NEUTRAL

## Step 4 Token Build

建立 Color Token：

-   token
-   hex
-   role
-   priority
-   locked

## Step 5 Ratio Build

默认：

PRIMARY 45% SECONDARY 25% NEUTRAL 20% ACCENT 10%

## Step 6 Validation

执行颜色一致性检查。

------------------------------------------------------------------------

# Output Interface

输出：

-   Color System
-   Color Token
-   Color Role
-   Color Ratio
-   Color Priority
-   Lock State
-   Validation Result
-   Version

------------------------------------------------------------------------

# State Machine

状态：

DRAFT → CONFIRMED → LOCKED

## DRAFT

允许调整。

## CONFIRMED

用户确认颜色体系。

## LOCKED

核心颜色进入系统保护状态。

------------------------------------------------------------------------

# Workflow Lock

LOCKED 后：

允许：

-   明度调整
-   阴影变化
-   光影变化
-   背景适配
-   印刷适配

禁止：

-   修改 Primary
-   修改 IP 核心色
-   随机新增主色
-   替换 Color Token
-   擅自重新配色

------------------------------------------------------------------------

# QA 检查机制

检查：

-   核心颜色是否正确
-   Token 是否完整
-   Priority 是否完整
-   Ratio 是否完整
-   是否出现随机颜色
-   是否发生颜色漂移
-   是否违反 Lock

结果：

-   PASS
-   WARN
-   FAIL

------------------------------------------------------------------------

# Error Recovery

## 输入不足

要求补充 IP 参考资产。

## QA FAIL

停止下游流程：

1.  定位问题颜色
2.  修正
3.  重新 QA

## LOCKED 修改请求

创建新版本：

V1 → V2 → V3

禁止覆盖旧版本。

------------------------------------------------------------------------

# Asset Register

记录：

-   IP Reference
-   Color Token
-   Color System Version
-   Lock Status
-   Validation Status

------------------------------------------------------------------------

# Version Control

Skill Version:

1.0.0

Color System Version:

v1 / v2 / v3

任何核心颜色变化必须升级版本。

------------------------------------------------------------------------

# Runtime Observability

运行状态：

INPUT → COLOR_ANALYSIS → ROLE_ASSIGNMENT → TOKEN_BUILD → RATIO_BUILD →
LOCK_CHECK → VALIDATION → OUTPUT

记录：

``` json
{
 "skill":"color-system",
 "status":"completed",
 "input_status":"complete",
 "version":"v1",
 "lock_status":true,
 "validation":"pass"
}
```

------------------------------------------------------------------------

# Downstream Interface

下游 Skill 调用：

-   ColorSystem.primary
-   ColorSystem.secondary
-   ColorSystem.accent
-   ColorSystem.neutral
-   ColorSystem.ratio
-   ColorSystem.priority
-   ColorSystem.lock
-   ColorSystem.version

所有下游设计 Skill 必须读取统一 Color System。

------------------------------------------------------------------------

# Forbidden Actions

禁止：

-   自行改变 IP 核心颜色
-   自行新增主色
-   修改锁定 Token
-   越权决定视觉风格
-   替代其他 Skill

------------------------------------------------------------------------

# Completion Criteria

Skill 完成条件：

-   输入有效
-   核心颜色识别完成
-   Color Role 建立完成
-   Token 输出完成
-   Ratio 完成
-   Lock 状态明确
-   QA 通过
-   Runtime 状态记录完成
-   下游接口可调用


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-COLOR.md -->
