# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 5 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-sticker-gif-batch/SKILL.md | bytes=14957 | chars=7031 | sha256=606a64cc0c836f3649f82ee5c555c1d5c243ba8674ef068641c55fb71e5291d8 -->

---
name: ip-sticker-gif-batch
description: "IP 动态表情包批量生产：用户上传静态 IP 表情包图片（角色明确、已有表情/动作/文字、表情包语义清晰）时，自动为每张图片建立独立 Motion Job，经视觉分析→语义识别→动作设计→动态生成→质检→自动修复，输出可无限循环的 GIF 动态表情包（GIF 为唯一交付格式）。含治理规则：首轮生成前确认锁、成本提示与大批量评估、资产登记、运行时状态与完成标准。触发场景：上传单张/多张/分批的表情包图片并希望「做成动图/GIF/动态表情」、让 IP 动起来、批量生产表情包动图、把静态表情包动画化。不适用：IP 三视图、设计说明、普通海报、产品图、普通插画、建筑效果图、单纯角色立绘等非表情包性质素材。"
---

# IP 动态表情包批量生产（GIF）

## 核心定位

这是一个「上传即处理、单图即可启动、批量可扩展、动作优先、文字锁定、构图锁定、身体范围锁定、自动质检修复、GIF 唯一输出」的动态表情包生产系统。

- 核心公式：动态表情包 = 语义 × 主动作 × 表情 × 节奏 × IP一致性
- 目标不是让 IP 动起来，而是让 IP 用动作把表情包里的文字说出来。
- 每张静态 IP 表情包 → 对应 1 个动态 GIF。

## 触发与 Job 管理

- 用户上传一张或多张图片后，立即执行 INPUT VALIDATION，不以图片数量为触发条件（1 张即可启动）。
- 合格图片每张建立独立 Motion Job（STK-001、STK-002…），各 Job 互不干扰，独立完成全流程。
- 多张图片同时上传时并行处理；用户后续继续上传只处理新增图片。
- 已处理过的图片不得重新生成；重复上传同一图片自动识别为 DUPLICATE 并跳过。
- 在回复中维护内部任务表：`ID | 原图 | 构图 | 语义 | 主动作 | 状态`。

## 确认锁与成本提示（治理规则）

- **Dynamic Confirmation Lock（生成确认锁）**：本 Skill 不在任何上游流程结束后自动接续生成。开始批量动画化前，先与用户确认「是否需要对这批表情包做动态化」，得到明确确认后才建立 Motion Job。
- **Cost Notice（成本提示）**：确认时同步提示「动态表情生成会消耗更多创作额度；大批量时使用豆包批量生成更划算」。
- **Batch Evaluation（批量评估）**：单张 / 少量（≤5 张）：在当前流程内直接继续。大批量：提示额度消耗后由用户决定「继续当前流程」或「分批 / 缩小范围」。**不自动跳转外部平台，不擅自缩减任务。**
- 用户已明确表达「做成动图 / GIF / 动态表情」意图时，上述确认与提示仅需一次，不逐张重复询问。

## INPUT VALIDATION 标准

**合格（进入流程）**：IP 人物/角色明确；已有表情、动作或文字；表情包语义明确；适合动态化。允许：全身/半身/大头胸像、带文字/不带文字、带简单道具或装饰。

**不合格（不进入流程，说明原因）**：IP 三视图、IP 设计说明、普通宣传海报、产品图、普通插画、建筑效果图、单纯角色立绘、非表情包性质的视觉素材。

## 每 Job 工作流

1. 读取原图（用 Read 打开本地图片，thumbnail_size 调大到文字与细节清晰；必要时分区读）
2. 视觉分析 → 3. 语义识别 → 4. 设计 Motion Plan → 5. 五大 Lock 检查
6. 动态生成（image_to_video）→ 7. GIF 转换 → 8. GIF 压缩（≤500KB）→ 9. QA 检查 →（FAIL → 自动修复，最多 2 次）→ 10. GIF 输出

## 1 视觉分析（生成前必做）

逐项识别并记录：

- **IP 身份**：主体角色、脸型、五官、眼睛、鼻子、嘴巴、发型、帽子、耳朵、服装、配饰、色彩、IP 特征、身体比例、手脚比例、特殊造型。
- **当前姿态**：站立/坐姿/半身/全身/胸像、正面/侧面/三分之四、手臂位置、手势、头部角度、身体倾斜、道具位置。
- **表情**：开心/严肃/惊讶/生气/委屈/思考/鼓励/温柔/无奈/得意/拒绝/认可等。
- **文字**：主文字、副文字、标语、数字、品牌名、IP 名称、其他字符，逐一抄录。
- **道具**：安全帽、文件、工具、手机、手势道具等原图已有物件。**不得擅自新增道具。**

## 2 语义识别

综合「文字语义 + 原始动作 + 原始表情 + 人物姿态 + 视觉构图」确定这张表情包真正想表达什么。

| 文字 | 语义 | 文字 | 语义 |
|---|---|---|---|
| 加油 | 鼓励 | 收到 | 确认/执行 |
| 谢谢 | 感谢 | 注意 | 提醒 |
| 拜拜 | 告别 | 欢迎 | 欢迎 |
| 没问题 | 肯定 | 稍等 | 等待 |
| 报告隐患 | 汇报/指认 | 点赞 | 肯定 |
| 辛苦了 | 慰问 | 加班 | 工作状态 |
| 危险 | 警示 | OK | 确认 |

规则：若文字与人物动作冲突，**优先保留原始人物姿态**，通过合理的动作延展强化语义，而不是彻底重新设计人物。

## 3 Motion Plan 设计

### 主动作原则（最重要）

每张表情包至少设计一个**明确、可识别、具有语义的主动作**。

**禁止**仅凭以下辅助动态交付：嘴巴张合、眨眼、轻微呼吸、头部轻微晃动、衣服轻微摆动。这些只能作为主动作的辅助。

正确示例（加油）：握拳 → 手臂上举 → 身体跟随 → 再次挥拳 → 表情坚定 → 嘴巴辅助说「加油」。

### 动作结构

每个动画自动建立：`预备 → 主动作 → 动作峰值 → 回收 → 原始状态 → 循环`（第一帧 ≈ 最后一帧，循环自然无跳帧）。

### 动作优先级

`原始动作/姿态 ＞ 语义 ＞ 动作库`。原图已是握拳/指向/挥手/鼓掌/双手展开等动作时，优先围绕原动作动态扩展，不强行改变角色姿势。

### 动作强度系统

- **L1 轻动作**（谢谢、温馨提醒、欢迎、思考、无奈）：动作清晰、节奏舒缓、不夸张。
- **L2 标准动作**（收到、点赞、拜拜、注意、OK、稍等）：动作明显、表情丰富、有明确峰值。
- **L3 强动作**（加油、庆祝、鼓掌、警告、生气、强烈鼓励）：幅度大、节奏鲜明、身体跟随明显、可重复 2–3 次。

### 动作语义参考库

逐语义的主动作建议（握拳挥臂、竖拇指、挥手 2–3 次、双手展开、点头/鞠躬、指向、制止手势、OK 手势、敬礼、暂停手势、举手汇报、拍掌 2–3 次、后仰、摇头+拒绝、思考手型、摊手耸肩、前倾握拳、跳跃上扬等）见 `references/motion-library.md`。**动作库仅作参考，禁止机械套用**，须结合原图姿态与文字语义。

### Silent Action Test（每 Job 必做）

动画生成后，忽略文字、声音与嘴巴动作，只看人物动作和表情：是否仍能大致理解这张表情包的意思？不能 → FAIL，自动增强主动作（例如「加油」只有嘴巴+眨眼 → 必须加握拳、挥拳、身体跟随）。

## 4 五大 Lock

每个 Job 生成前逐条核对，任何一条不满足即禁止生成：

- **① Identity Lock（IP 身份锁）**：锁定脸型、五官、眼睛、鼻子、嘴巴、发型、帽子、耳朵、服装、配饰、色彩、IP 特征、身体比例。这是静态表情包动画化，不是再创作；禁止换脸/换装/换帽/改色/改比例/改造型。
- **② Composition Lock（构图锁）**：保持原始画布比例、镜头、构图、裁切边界、人物大小、人物位置、文字位置。禁止自动缩放、重新构图、镜头移动/旋转/推拉/摇晃、扩展画布。
- **③ Typography Lock（文字锁）**：原图所有文字（中文/英文/数字/标点/IP 名/品牌名/Logo 文字/标语）100% 保持原样。禁止错字、缺字、增字、字体变化、字形变形、文字融化、闪烁、漂移、抖动、AI 重新生成文字。
- **④ Motion Boundary Lock（动作边界锁）**：以 Body Visibility Map 为准——原图可见哪些身体部分，才允许哪些部分动。全身图：头、身体、双手、双腿、鞋子可参与；半身图：只允许头部+上半身+手臂，禁止生成腰部以下、腿、鞋；胸像：只允许头部、肩膀、胸部合理动态。**禁止 AI 补全下半身**。Forbidden Zone：原图不可见身体、新人物、新角色、新道具、新背景、新文字、新装饰、新 Logo 一律禁止出现。
- **⑤ Animation Language Lock（动画语言锁）**：统一语言 = 高品质 3D/2.5D IP 动态表情包、动作明确、活泼、节奏清晰、轻微夸张、表情丰富、干净利落、高识别度，最终要有「表情包感」而不是「动画感」。不是电影镜头、MV、写实动画、慢动作大片、复杂镜头运动。

## 5 动态生成（视频 → GIF 两段式）

### 5.1 生成动画视频

- 调用 `image_to_video` 前，**必须先 Read `doubao-creative-video/SKILL.md`** 并按该 Skill 要求准备与调用（工具强制要求）。
- 以原图为 `image_reference_url_list` 唯一参考图（如有本地图先用 FileBatchUpload 拿 URL）。
- `ratio` 取原图画布比例（如原图方形用 1:1，宽屏用 16:9），不得改变构图。
- `duration` 默认 3 秒（语义需要可 2.5–3.5 秒），保证循环自然。
- Prompt 按 `references/generation-prompt.md` 的模板写：包含主动作、强度、身体跟随、表情、嘴巴辅助、辅助动态、以及全部 Lock 约束（身份不变、文字不变不遮、构图不变、不补身体、循环首尾一致）。禁止在 Prompt 里要求任何镜头运动、背景变化、新增元素。
- 模型版本：默认 seedance_2.0；无需指定时不要乱用 2.5（若用户指定 seedance2.5 必须先读 `seedance-25` Skill）。

### 5.2 转换 GIF

- 调用 mediakit 前先 Read `byted-mediakit-editing/SKILL.md`，用其 `extract-animated-image`（mediakit-cli editing extract-animated-image）把整段视频转为 GIF，覆盖完整时长，保持无限循环。
- **GIF 为唯一交付格式**：禁止输出 MP4/MOV/AVI/WebM，禁止 GIF+MP4 同时交付。MP4 仅作为中间产物存在，可用后清理。

### 5.3 GIF 压缩（≤500KB，微信表情包上传硬性要求）

GIF 转换后必须压缩到 **500KB 以下**（微信表情商店主图硬性限制，超 1 字节即审核不通过）。详细压缩流程、参数迭代表与 ffmpeg 二进制获取方式见 `references/gif-compression.md`。

- 使用 **ffmpeg 调色板两步法**（palettegen + paletteuse），优于 Pillow 原生 GIF 编码器。
- 从高质量参数开始自动迭代降级（宽度 240→180px、帧率 12→8fps、颜色 256→64），首个满足 ≤500KB 的参数组合即停。
- 压缩后验证：文件大小 ≤ 500KB，且动画播放正常、文字清晰、IP 不变形。
- 微信表情包其他规格参考：建议尺寸 240×240（最大 ≤500×500）、动画 ≤3 秒、帧数 ≤20 帧。压缩时在满足 500KB 的前提下尽量保留最高画质。

## 6 QA 与自动修复

逐 Job 执行 QA-01～QA-10（IP 一致性 / 手部 / 身体 / 构图 / 文字 / 语义 / Silent Action Test / 动画自然度 / 背景稳定 / 文件大小 ≤500KB），细则见 `references/qa-checklist.md`。

- FAIL 时识别错误码（FACE_DEFORMATION / HAND_ERROR / BODY_ERROR / COMPOSITION_ERROR / LOWER_BODY_GENERATION / TEXT_ERROR / SEMANTIC_MISMATCH / WEAK_ACTION / CAMERA_MOVEMENT / LOOP_ERROR / FILE_TOO_LARGE），修改 Motion Plan 与生成 Prompt 后重新生成（FILE_TOO_LARGE 只需重新压缩，不需要重新生成动画）。
- **最多自动修复 2 次**，禁止无限重复生成。
- 最终状态：`PASS` / `AUTO REPAIR` / `FAIL` / `DUPLICATE` / `COMPLETE`，全部在任务表中展示。

## 7 输出与命名

- 每张原图 → 1 个 GIF：无限循环、2.5–3.5 秒、**≤500KB**、保持原始画布比例与构图、文字清晰、IP 一致、可见身体范围正确、动作符合语义。
- 命名优先 `[IP名称]_[语义].gif`（如 宣哥_加油.gif、安安虎_收到.gif）；无法识别语义时 `[IP名称]_Motion_001.gif` 递增。
- GIF 放主项目目录，最终通过 `present_files` 交付。

## 资产登记（Asset Register）

每个完成的 Job 登记一条资产记录，并并入任务表展示：

| 字段 | 内容 |
|---|---|
| Asset ID | 如 STK-001-DYN |
| 源静态表情 | 原图文件名 |
| 动画描述 | 主动作 + 语义 |
| 生成状态 | PASS / AUTO REPAIR / FAIL / DUPLICATE |
| QA 结果 | QA-01~10 通过项 |
| GIF 位置 | 最终文件路径 |
| 版本 | 当前 Skill 版本 |

登记信息供下游流程（IP Design OS / 表情资产库 / 传播物料工作流 / 社媒资产管线）调用。

## 禁止行为速查

- 不因图片数量不足而停止；不要求用户一次上传全部表情包；不重复生成已处理图片。
- 不自动重新设计 IP、不改变脸部/服装/颜色/身体比例、不半身变全身、不补腿/补鞋、不生成隐藏身体。
- 不新增人物、道具、背景元素；不改文字、不产生文字乱码/漂移。
- 不只做嘴巴/眨眼/呼吸/轻晃动画；不为套模板强行改变原图动作。
- 无镜头推拉/旋转/抖动、不自动改构图。
- 不输出 MP4（或 GIF+MP4 同时输出）；不无限自动修复。
- 不交付超过 500KB 的 GIF（微信表情包上传硬性要求）。

## 规则冲突优先级

规则冲突时按下述优先级执行：

`01 IP一致性 → 02 原始构图与身体可见范围 → 03 文字准确与稳定 → 04 语义准确 → 05 主动作表达 → 06 表情强化 → 07 辅助动态 → 08 装饰性动态`

即：宁可动作简单也不能破坏 IP；宁可少动也不能生成原图不存在的身体；宁可减少动作幅度也不能破坏文字。但在满足上述锁定后，绝不能把动画做成只有眨眼、呼吸、嘴巴说话的「伪动态」。

## 运行时状态（Runtime Observability）

任务表状态列按以下符号持续展示当前进度：

`○ 未开始 → ● 执行中 → ◐ 等待确认 → ✓ 完成 → ✗ FAIL`

单 Job 全流程状态：Static Asset Check → 语义分析 → Motion Planning → 生成 → GIF 处理 → QA → 完成。每步状态随回复更新，不滞后、不虚构。

## 完成标准（Completion Criteria）

一个 Job 视为完成，需同时满足：

1. 用户确认已获得（本次任务首轮）
2. 动态动画已生成
3. GIF 已处理（≤500KB、循环自然、文字清晰）
4. QA 全部通过（或自动修复后通过）
5. 资产记录已登记
6. 任务表状态已更新为完成

## 下游接口（Downstream Interface）

输出 GIF 可被以下流程消费：IP Design OS / 表情资产库 / 传播物料工作流 / 社媒资产管线。生产规则、Lock 与 QA 标准不变。


<!-- END SOURCE: skills/ip-sticker-gif-batch/SKILL.md -->


<!-- BEGIN SOURCE: skills/ip-sticker-gif-batch/references/generation-prompt.md | bytes=3906 | chars=3138 | sha256=9b40a87a0a6b2a11ebf8c4e66810ad2eb174a4bcd06bb936a8ed97527e9b4b01 -->

# 动态生成 Prompt 模板（image_to_video）

> 调用 `image_to_video` 前，必须先 Read `doubao-creative-video/SKILL.md`。以下模板用于把 Motion Plan 转成生成 Prompt，并按需翻译为英文（模型对英文动作描述通常更稳定，可中英混合：动作用英文，锁定约束用中英双语强调）。

## 模板

```
Reference image is the ONLY source of character identity, costume, colors, pose, composition and all text.
Task: animate this sticker character performing ONE clear main action.

MAIN ACTION: <主动作描述，来自 Motion Plan，如 "clench right fist and punch upward twice with body following">
ACTION LEVEL: <L1/L2/L3>
BODY FOLLOW: <肩膀/上半身/手臂/头等可见部分>
EXPRESSION: <表情强化，如 "determined, energetic smiling eyes">
MOUTH: <辅助说话，如 "mouth slightly speaks the word 加油">
SECONDARY MOTION: <衣服/头发轻微惯性，如 "subtle cloth inertia only">

HARD CONSTRAINTS (must follow all):
1. Keep the character IDENTICAL: same face, facial features, hairstyle, hat, ears, outfit, accessories, colors, body proportions. NO redesign.
2. Keep composition 100% fixed: same canvas ratio, same framing, same crop, same character size and position, same background. NO camera movement, NO zoom, NO pan, NO rotation, NO shake. NO new background elements.
3. Keep ALL original text EXACTLY as in the reference: same characters, same font, same position, same size. Text must stay static and clear, never deform, flicker, drift, or get covered by the character's arm/hand. NO new text.
4. Only animate body parts visible in the reference image. NEVER generate legs, feet, shoes or any hidden body parts that are not in the frame.
5. NO new props, no new characters, no new decorations, no logos.
6. Loop-friendly: start and end pose must match the original reference pose so the GIF loops smoothly.
7. Style: lively 3D/2.5D sticker animation, clear rhythm, slightly exaggerated, clean and snappy — NOT cinematic, NOT realistic, NO slow-motion drama.
```

## 使用示例

输入 Motion Plan：

```
STK-023 文字：加油 语义：鼓励 原始姿态：右手握拳
主动作：握拳向上挥动2次 强度：Level 3
身体跟随：肩膀+上半身 表情：坚定、积极
嘴巴：辅助说「加油」 辅助动态：衣服轻微惯性
循环：准备 → 挥拳 → 峰值 → 回落 → 第二次挥拳 → 回到原始状态
```

生成 Prompt：

```
Reference image is the ONLY source of character identity, costume, colors, pose, composition and all text.
MAIN ACTION: clench the raised fist and punch upward twice, shoulder and upper body follow the punch rhythm.
ACTION LEVEL: L3 (strong, energetic).
EXPRESSION: determined, motivated, bright eyes.
MOUTH: slightly speaks the word "加油" as auxiliary only.
SECONDARY MOTION: subtle cloth inertia on sleeves only.
HARD CONSTRAINTS: keep character identical (same face/outfit/colors/proportions, no redesign);
keep composition 100% fixed, no camera movement/zoom/rotation/shake, no new background;
keep the original text "加油" exactly static, clear and uncovered;
only animate visible upper body and arm, NEVER generate legs/feet/hidden body parts;
no new props or characters; loop-friendly, start and end return to the original pose;
style: lively 3D/2.5D sticker animation, snappy, not cinematic.
```

## Prompt 编写红线

- 不写「镜头运动、推拉、旋转、晃动、变焦」。
- 不写「改变背景、增加场景、更换服装、换发型」。
- 不写「生成完整身体/腿/鞋子」——若原图是半身，明确写 `NEVER generate legs, feet, shoes, or any body parts below the waist`。
- 不写「重新排版文字、修改文字」——明确写文字 100% 保持原样且不被遮挡。
- 主动作必须具体可执行（动作名称 + 次数 + 身体跟随），避免只有「微笑、眨眼、呼吸」。


<!-- END SOURCE: skills/ip-sticker-gif-batch/references/generation-prompt.md -->


<!-- BEGIN SOURCE: skills/ip-sticker-gif-batch/references/gif-compression.md | bytes=5972 | chars=4443 | sha256=58f6bc39297c7d1ead709595341fb834ed9162cb0cefd795e695ca65018398b6 -->

# GIF 压缩流程（≤500KB）

> 微信表情商店主图硬性要求：**文件 ≤ 500KB**（超 1 字节即审核不通过）。本文件记录经过实测验证的 ffmpeg 调色板两步压缩法，以及自动迭代参数策略。

## 为什么用 ffmpeg 而不是 Pillow

Pillow 原生 GIF 编码器效率低，在同等画质下输出体积通常是 ffmpeg 调色板法的 2~3 倍。实测对比（同一 480×640、75帧、2479KB 源文件）：

| 工具 | 达到 500KB 所需参数 | 画质感受 |
|---|---|---|
| Pillow | 240px 宽 + 跳帧2 + 64色 | 色带明显、帧卡顿 |
| ffmpeg 调色板法 | 200px 宽 + 8fps + 64色 | 颜色过渡自然、帧间平滑 |

ffmpeg 的 `palettegen=stats_mode=diff` + `paletteuse=diff_mode=rectangle` 只对帧间变化区域做有损处理，静态区域逐帧保留，远优于全帧重编码。

## ffmpeg 二进制获取

环境中可能没有预装 ffmpeg。通过 Python `imageio-ffmpeg` 包获取预编译二进制：

```powershell
python -m pip install imageio-ffmpeg --quiet
python -c "import imageio_ffmpeg; print(imageio_ffmpeg.get_ffmpeg_exe())"
```

输出路径形如：
`...\site-packages\imageio_ffmpeg\binaries\ffmpeg-win-x86_64-v7.1.exe`

后续所有命令中 `FFMPEG` 变量指向该路径。

## 两步压缩法

### Step 1：生成自适应调色板（palettegen）

```
ffmpeg -y -i input.gif -vf "fps=<FPS>,scale=<WIDTH>:-1:flags=lanczos,palettegen=max_colors=<COLORS>:stats_mode=diff" -update 1 palette.png
```

关键参数：
- `fps=<FPS>`：降帧率，直接减少总帧数（如 10→8fps）。
- `scale=<WIDTH>:-1`：等比缩放到指定宽度，高度自动计算，`flags=lanczos` 保证缩放质量。
- `palettegen=max_colors=<COLORS>`：调色板颜色数（256/128/64），颜色越少体积越小。
- `stats_mode=diff`：只统计帧间差异区域的颜色分布，动画区域调色板更精准。
- `-update 1`：**必须加**，ffmpeg 7.x 写单帧 PNG 时需要此参数，否则 palettegen 会输出警告且调色板不正确。

### Step 2：用调色板编码（paletteuse）

```
ffmpeg -y -i input.gif -i palette.png -lavfi "fps=<FPS>,scale=<WIDTH>:-1:flags=lanczos [x]; [x][1:v] paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle" output.gif
```

关键参数：
- `[x][1:v]`：把缩放后的视频流与调色板流串联。
- `dither=bayer:bayer_scale=5`：有序抖动，比默认 floyd-steinberg 抖动产生的 GIF 体积小很多，且画质可接受。
- `diff_mode=rectangle`：只在帧间差异矩形区域应用调色板，进一步减小体积。

## 自动参数迭代表

从最高画质开始尝试，**首个满足 ≤500KB 的组合即停**。参数按优先级排列（越靠前画质越好）：

| 优先级 | 宽度 | 帧率 | 颜色 | 适用场景 |
|---|---|---|---|---|
| 1 | 240px | 12fps | 256 | 源文件较小（<2MB）、动作少 |
| 2 | 240px | 12fps | 128 | |
| 3 | 240px | 12fps | 64 | |
| 4 | 220px | 12fps | 256 | |
| 5 | 220px | 12fps | 128 | |
| 6 | 220px | 12fps | 64 | |
| 7 | 240px | 10fps | 256 | |
| 8 | 240px | 10fps | 128 | |
| 9 | 240px | 10fps | 64 | |
| 10 | 220px | 10fps | 256 | |
| 11 | 220px | 10fps | 128 | |
| 12 | 220px | 10fps | 64 | |
| 13 | 200px | 10fps | 256 | |
| 14 | 200px | 10fps | 128 | |
| 15 | 200px | 10fps | 64 | |
| 16 | 240px | 8fps | 256 | |
| 17 | 240px | 8fps | 128 | |
| 18 | 240px | 8fps | 64 | |
| 19 | 220px | 8fps | 256 | |
| 20 | 220px | 8fps | 128 | |
| 21 | 220px | 8fps | 64 | |
| 22 | 200px | 8fps | 256 | |
| 23 | 200px | 8fps | 128 | |
| 24 | 200px | 8fps | 64 | |
| 25 | 180px | 8fps | 128 | 兜底：源文件很大（>3MB） |
| 26 | 180px | 8fps | 64 | 兜底 |

**实测结果**：对 1.3~4MB 的竖版 IP 表情包（480×640~480×854，45~75帧），绝大多数在第 15~24 档之间命中（200px/8~10fps/64色 ≈ 400~500KB）。

## 批量处理脚本模板

```python
import subprocess, os

FFMPEG = "<imageio_ffmpeg 返回的 ffmpeg.exe 路径>"
TARGET = 500 * 1024  # 500KB

def compress_one(input_path, output_path, palette_path):
    strategies = [
        (240,12,256),(240,12,128),(240,12,64),
        (220,12,256),(220,12,128),(220,12,64),
        (240,10,256),(240,10,128),(240,10,64),
        (220,10,256),(220,10,128),(220,10,64),
        (200,10,256),(200,10,128),(200,10,64),
        (240,8,256),(240,8,128),(240,8,64),
        (220,8,256),(220,8,128),(220,8,64),
        (200,8,256),(200,8,128),(200,8,64),
        (180,8,128),(180,8,64),
    ]
    for w, fps, c in strategies:
        # palettegen
        subprocess.run([FFMPEG,"-y","-i",input_path,"-vf",
            f"fps={fps},scale={w}:-1:flags=lanczos,palettegen=max_colors={c}:stats_mode=diff",
            "-update","1",palette_path], capture_output=True)
        if not os.path.exists(palette_path): continue
        # paletteuse
        subprocess.run([FFMPEG,"-y","-i",input_path,"-i",palette_path,"-lavfi",
            f"fps={fps},scale={w}:-1:flags=lanczos [x]; [x][1:v] paletteuse=dither=bayer:bayer_scale=5:diff_mode=rectangle",
            output_path], capture_output=True)
        if os.path.exists(output_path) and os.path.getsize(output_path) <= TARGET:
            return os.path.getsize(output_path), f"{w}px/{fps}fps/{c}c"
    return None, None
```

## 压缩后验证

1. **文件大小**：`os.path.getsize(output) <= 500 * 1024`。
2. **动画完整性**：用 Read 打开输出 GIF 查看，确认帧数完整、循环正常、无卡死。
3. **文字清晰度**：确认压缩后原图文字仍可读（降色后文字不应模糊到无法辨认）。
4. **IP 一致性**：角色面部、服装颜色不应出现明显色偏或色块。

## 微信表情包规格备忘

| 项目 | 要求 |
|---|---|
| 文件大小 | ≤ 500KB（主图） |
| 格式 | GIF（动图）或 PNG（静图） |
| 尺寸 | 建议 240×240，最大 ≤ 500×500 |
| 动画时长 | 建议 ≤ 3 秒 |
| 帧数 | 建议 ≤ 20 帧更安全 |
| 缩略图 | ≤ 50KB，与主图数量一致 |


<!-- END SOURCE: skills/ip-sticker-gif-batch/references/gif-compression.md -->


<!-- BEGIN SOURCE: skills/ip-sticker-gif-batch/references/motion-library.md | bytes=4147 | chars=1913 | sha256=43cc2e3aef67ad6b5c0eedbe07d673a69ece25e700b06313466dea508e920dab -->

# 动作语义参考库（Motion Library）

> 仅作参考，禁止机械套用。每个 Job 必须结合：原图姿态 > 文字语义 > 动作库。

## 逐语义主动作建议

| 语义 | 主动作 | 强度 | 身体跟随 | 表情 |
|---|---|---|---|---|
| 加油 | 握拳挥臂 / 拳头上举 2 次 | L3 | 肩膀 + 上半身 | 坚定、积极 |
| 点赞 | 明确竖起拇指，手臂向前 | L2 | 手臂 + 肩膀 | 肯定、满意 |
| 拜拜 | 手掌左右挥动 2–3 次 | L2 | 手臂 + 头部 | 微笑、亲切 |
| 欢迎 | 双手展开 / 手掌迎接，身体微微前倾 | L1–L2 | 上半身 | 热情、开朗 |
| 谢谢 | 点头 / 轻微鞠躬，双手配合 | L1 | 头 + 上半身 | 温柔、感激 |
| 注意 | 指向 / 举手提醒，身体轻微前倾 | L2 | 手臂 + 上半身 | 认真、提醒 |
| 警告 | 制止手势 / 手掌向前，身体强化反应 | L3 | 手臂 + 身体 | 严肃、警示 |
| OK | OK 手势 + 轻微确认动作 | L2 | 手 + 头 | 自信、确认 |
| 收到 | 敬礼 / 点头 / 确认手势 | L2 | 手 + 头 | 可靠、回应 |
| 稍等 | 手掌向前「暂停」手势 | L2 | 手 + 头 | 安抚、等待 |
| 报告隐患 | 举手 / 指向隐患位置 / 汇报动作 | L2–L3 | 手臂 + 上半身 | 认真、急切 |
| 鼓励 | 握拳向前 / 鼓励动作 | L2–L3 | 手臂 + 身体 | 温暖、坚定 |
| 鼓掌 | 双手拍掌 2–3 次 | L3 | 双手 + 上半身 | 开心、认可 |
| 惊讶 | 身体后仰 / 双手反应 / 眼睛睁大 | L2 | 身体 + 头 | 惊讶、夸张 |
| 拒绝 | 摇头 + 手掌拒绝 / 手指摆动 | L2 | 头 + 手 | 坚决、无奈 |
| 思考 | 头部倾斜 + 眼神移动 + 手部思考动作 | L1 | 头 + 手 | 沉思、疑惑 |
| 无奈 | 摊手 + 耸肩 + 摇头 | L1 | 双肩 + 手 | 无奈、苦笑 |
| 生气 | 握拳 / 身体前倾 / 强烈表情 | L3 | 身体 + 手臂 | 生气、不满 |
| 庆祝 | 双手举起 / 握拳 / 身体上扬 | L3 | 全身可见部分 | 兴奋、喜悦 |

## 动作强度系统

- **L1 轻动作**：谢谢、温馨提醒、欢迎、思考、无奈。动作清晰、节奏舒缓、不夸张。
- **L2 标准动作**：收到、点赞、拜拜、注意、OK、稍等。动作明显、表情丰富、有明确动作峰值。
- **L3 强动作**：加油、庆祝、鼓掌、警告、生气、强烈鼓励。幅度更大、节奏鲜明、身体跟随更明显、可重复 2–3 次。

## 动作结构（每动画统一建立）

```
预备 → 主动作 → 动作峰值 → 回收 → 原始状态 → 循环
```

- 循环必须自然：第一帧 ≈ 最后一帧，首尾不跳帧。
- 默认 2.5–3.5 秒，按语义允许单次/双次/三次重复动作。

## 动作优先级

`原始动作/姿态 ＞ 语义 ＞ 动作库`

原图已握拳/指向/挥手/鼓掌/双手展开时，优先围绕原动作动态扩展，不得强行改变角色姿势去套模板。

## 主动作判定（不够格的伪动态）

以下不能作为主动作交付，只能作为辅助：

- 嘴巴张合、眨眼、轻微呼吸、头部轻微晃动、衣服轻微摆动。

每张表情包必须至少一个：明确、可识别、具有语义的主动作（握拳挥臂、指向、挥手、拍掌、竖拇指、鞠躬、摊手等）。

## 辅助动态层次（只服务主动作）

```
主动作 ↓ 身体跟随 ↓ 服装/头发惯性 ↓ 表情强化 ↓ 辅助细节
```

辅助动态（头发、衣服、袖口、裙摆、配饰、帽带、原道具）不得比主动作更明显。

## Silent Action Test

动画生成后：**忽略文字、声音和嘴巴动作**，只观察动作与表情——能否仍大致理解这张表情包的意思？

- 能 → 通过。
- 不能 → FAIL，自动增强主动作（如「加油」只有嘴巴+眨眼 → 必须增加握拳、挥拳、身体跟随等明确动作）。

## 动作设计禁止

- 为套模板强行改变原图动作。
- 只做嘴巴/眨眼/呼吸/轻微晃动/衣服摆动即交付。
- 半身图动作延展到腰部以下（补腿/补鞋/生成隐藏身体）。
- 手臂穿透文字、遮挡文字、穿过文字、改变文字层级（除非原图本身就有遮挡关系）。


<!-- END SOURCE: skills/ip-sticker-gif-batch/references/motion-library.md -->


<!-- BEGIN SOURCE: skills/ip-sticker-gif-batch/references/qa-checklist.md | bytes=2556 | chars=1254 | sha256=ebbdce6519e89d0b59e50284f2e0218b8aeb9c47ab578a1fd7108f376423a023 -->

# QA 检查清单与自动修复

每 Job 生成 GIF 后逐项检查，全部通过才标记 PASS。

## QA-01 IP 一致性

检查：脸、五官、发型、服装、配饰、色彩、身体比例是否与原图一致。
失败码：`FACE_DEFORMATION`（脸/五官变形）。

## QA-02 手部检查

检查：手指数量、手指结构、手部比例、手腕连接、是否多手、是否残缺手。
失败码：`HAND_ERROR`。

## QA-03 身体检查

检查：是否生成隐藏身体、是否改变身体比例、是否出现多余肢体、是否身体穿模。
失败码：`BODY_ERROR`；出现下半身补全/补腿/补鞋 → `LOWER_BODY_GENERATION`。

## QA-04 构图检查

检查：人物是否越界、是否改变裁切、是否改变人物位置、是否发生镜头运动。
失败码：`COMPOSITION_ERROR` / `CAMERA_MOVEMENT`。

## QA-05 文字检查

检查：错字、乱码、缺字、多字、文字变形、文字闪烁、文字漂移、文字遮挡。
失败码：`TEXT_ERROR`。

## QA-06 语义检查

检查：动作是否真正表达文字含义（动作与语义匹配）。
失败码：`SEMANTIC_MISMATCH`。

## QA-07 Silent Action Test

不看文字、不看嘴巴，仅看动作和表情，是否仍能理解大致语义。
失败码：`WEAK_ACTION`（主动作缺失/过弱，如只有眨眼、呼吸、嘴巴）。

## QA-08 动画自然度

检查：卡顿、突然跳动、动作机械、动作过弱、动作过度、循环突兀。
失败码：`LOOP_ERROR`。

## QA-09 背景稳定

检查：背景不得出现不必要变化（保持原图背景与底色）。

## QA-10 文件大小（≤500KB）

检查：GIF 文件大小必须 ≤ 500KB（微信表情商店主图硬性限制，超 1 字节即审核不通过）。
失败码：`FILE_TOO_LARGE`。
修复方式：按 `references/gif-compression.md` 的参数迭代表进一步降低宽度/帧率/颜色数后重新压缩（不需要重新生成动画，只需对已有 GIF 重新压缩）。

## 自动修复流程

1. 识别失败类型，映射错误码。
2. 修改 Motion Plan 与生成 Prompt（强化主动作、收紧 Lock 约束、明确禁止项）。
3. 重新生成并复检。
4. **最多自动修复 2 次**，禁止无限重复生成。

## 状态机

| 状态 | 含义 |
|---|---|
| PROCESSING | 处理中 |
| PASS | QA 全部通过 |
| AUTO REPAIR | 曾失败，修复后通过 |
| FAIL | 2 次修复后仍未通过（如实报告，交付可用的最优版本或说明原因） |
| DUPLICATE | 重复上传，跳过 |
| COMPLETE | 已交付 |


<!-- END SOURCE: skills/ip-sticker-gif-batch/references/qa-checklist.md -->
