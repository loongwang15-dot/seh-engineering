# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-ASSET-INTERFACE.md | bytes=8824 | chars=8194 | sha256=ddc822e8d5158334608dbb60d889638a367cc0da62448365f47b770305b90102 -->

---
name: asset-interface
description: "资源接口 / Asset Interface Skill（基础设施层，v1.0.0）：使 IP 设计资产可识别、可调用、可追溯、可锁定、可版本化。核心原则：本 Skill 管理资产，不负责设计创作。职责：统一资产注册、资产身份管理、版本控制、状态管理、跨 Skill 资产传递、资产依赖管理、资产一致性校验、运行时追踪。触发：创建/查询/调用/更新可复用设计资产、创建资产版本、锁定/解锁/废弃/归档资产、检查资产依赖、跨 Skill 传递资产、校验资产可用性。禁止执行设计创作任务：IP 人物、三视图、配角、表情包、海报、条漫、服装、色彩系统、字体设计及最终视觉输出（归专门业务 Skill）。"
version: 1.0.0
status: Production
layer: Infrastructure Layer
---

# Asset Interface Skill

## Metadata

-   Skill Name: Asset Interface
-   Skill ID: asset-interface
-   Version: 1.0.0
-   Status: Production
-   Layer: Infrastructure Layer

------------------------------------------------------------------------

# 1. Skill Positioning

Asset Interface is the infrastructure layer responsible for making IP
design assets identifiable, callable, traceable, lockable, and
version-controlled.

Core principle:

> This Skill manages assets, not design creation.

Responsibilities: - Unified asset registration - Asset identity
management - Version control - State management - Cross-Skill asset
transmission - Asset dependency management - Asset consistency
validation - Runtime tracking

------------------------------------------------------------------------

# 2. Trigger Rules

Activate when:

-   Creating reusable design assets
-   Querying existing assets
-   Calling existing assets
-   Updating assets
-   Creating asset versions
-   Locking assets
-   Unlocking assets
-   Deprecating assets
-   Archiving assets
-   Checking asset dependencies
-   Transferring assets between Skills
-   Validating asset availability

------------------------------------------------------------------------

# 3. Non Trigger Rules

Do not execute design creation tasks.

Forbidden responsibilities:

-   Creating IP characters
-   Designing three-view sheets
-   Designing supporting characters
-   Designing expression packs
-   Designing posters
-   Designing comics
-   Designing costumes
-   Designing color systems
-   Designing typography
-   Generating final visual outputs

These operations belong to dedicated business Skills.

------------------------------------------------------------------------

# 4. Input Interface

``` yaml
asset_input:
  asset_id:
    required: false

  asset_name:
    required: true

  asset_type:
    required: true

  source:
    type:
      - image
      - file
      - skill_output
      - user_input
      - existing_asset

  reference:
    required: false

  parent_asset:
    required: false

  requested_operation:
    values:
      - create
      - read
      - update
      - lock
      - unlock
      - version
      - query
      - export
```

------------------------------------------------------------------------

# 5. Asset Register

Every registered asset must contain:

``` yaml
asset:
  identity:
    asset_id:
    name:
    type:
    version:
    status:

  visual_identity:
    silhouette:
    proportion:
    facial_features:
    costume:
    color:
    style:

  dependency:
    parent:
    children:
    related:

  usage:
    allowed:
    restricted:
    forbidden:

  qa:
    consistency:
    completeness:
    version_validity:
```

------------------------------------------------------------------------

# 6. Asset Types

    CHARACTER
     ├── MAIN_CHARACTER
     └── SUPPORT_CHARACTER

    CHARACTER_EXTENSION
     ├── THREE_VIEW
     ├── COSTUME
     ├── EXPRESSION
     └── ACTION

    VISUAL
     ├── COLOR
     ├── TYPOGRAPHY
     ├── GRAPHIC
     └── STYLE

    SCENE
     ├── BACKGROUND
     ├── ENVIRONMENT
     └── PROP

    OUTPUT
     ├── POSTER
     ├── COMIC
     ├── GIF
     └── OTHER

------------------------------------------------------------------------

# 7. Version Control

Asset identity remains unchanged across versions.

Example:

    ANANHU-CHAR-001

    V1.0
    V1.1
    V2.0 CURRENT

Version rules:

-   Every modification creates a new version.
-   Deprecated versions cannot be used for new production.
-   Current version must always be identifiable.

------------------------------------------------------------------------

# 8. State Machine

    CREATE
      ↓
    DRAFT
      ↓
    PROCESSING
      ↓
    QA
     ↓      ↓
    FAIL   PASS
     ↓      ↓
    PROCESSING APPROVED
                ↓
              LOCKED
             ↓     ↓
          UPDATE   USE
             ↓
        NEW VERSION
             ↓
             QA
             ↓
          LOCKED

    LOCKED
     ↓
    DEPRECATED
     ↓
    ARCHIVED

------------------------------------------------------------------------

# 9. Workflow

Standard workflow:

    REQUEST
     ↓
    IDENTIFY ASSET
     ↓
    VALIDATE INPUT
     ↓
    RESOLVE VERSION
     ↓
    CHECK DEPENDENCY
     ↓
    RETURN ASSET CONTRACT
     ↓
    BUSINESS SKILL EXECUTION
     ↓
    REGISTER OUTPUT
     ↓
    QA VALIDATION
     ↓
    VERSION UPDATE

------------------------------------------------------------------------

# 10. Workflow Lock

Locked assets protect:

-   Silhouette
-   Proportion
-   Primary colors
-   Costume structure
-   Facial features
-   Signature elements

When a locked asset requires modification:

    Create New Version
     ↓
    QA
     ↓
    Approval
     ↓
    Replace Current Version

------------------------------------------------------------------------

# 11. Asset Contract

``` yaml
asset_contract:

identity:
  asset_id:
  version:
  status:

visual:
  silhouette:
  proportion:
  color:
  costume:
  style:

constraints:
  must_keep:
  allowed_change:
  forbidden_change:

dependency:
  parent:
  children:

usage:
  allowed:
  restricted:
  forbidden:
```

------------------------------------------------------------------------

# 12. QA System

## Identity QA

-   Asset ID valid
-   Asset type valid
-   Version valid
-   Source recorded

## Version QA

-   Current version confirmed
-   Deprecated assets blocked
-   Dependency versions checked

## Consistency QA

-   Character consistency
-   Color consistency
-   Costume consistency
-   Feature preservation

## Interface QA

-   Input complete
-   Output readable
-   Downstream compatibility verified

------------------------------------------------------------------------

# 13. Error Recovery

Error Codes:

    AI-001 Asset Not Found

    AI-002 Version Not Found

    AI-003 Deprecated Asset

    AI-004 QA Failed

    AI-005 Asset Locked

    AI-006 Dependency Invalid

    AI-007 Version Conflict

    AI-008 Missing Input

    AI-009 Permission Error

    AI-010 Invalid Contract

Recovery:

    ERROR
     ↓
    Identify Error
     ↓
    Auto Repair Available?
     ↓
    YES → Repair → QA
    NO → Return Resolution Request

------------------------------------------------------------------------

# 14. Downstream Interface

Supported downstream Skills:

-   IP Character Design
-   Three View Design
-   Supporting Character Design
-   Expression Design
-   Costume Extension
-   Color System
-   Poster Design
-   Comic Design
-   Material Extension

Calling format:

    REQUEST ASSET
     ↓
    Asset Interface
     ↓
    Return Asset Contract
     ↓
    Business Skill Execute

------------------------------------------------------------------------

# 15. Runtime Observability

Every execution records:

``` yaml
runtime:

execution_id:
timestamp:

caller_skill:

operation:

asset_id:

requested_version:

resolved_version:

status:

dependency_check:

version_check:

lock_check:

qa_check:

output:

errors:

warnings:
```

------------------------------------------------------------------------

# 16. Forbidden Actions

Asset Interface must never:

-   Generate creative designs
-   Modify business Skill logic
-   Override locked assets
-   Skip QA validation
-   Delete historical versions
-   Hide asset conflicts
-   Use deprecated assets silently

------------------------------------------------------------------------

# 17. Completion Criteria

Skill execution is complete when:

-   Asset identity is confirmed
-   Correct version is resolved
-   Dependency validation passes
-   Contract is returned
-   Runtime record is created
-   Output asset is registered
-   QA status is updated

------------------------------------------------------------------------

# End


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-ASSET-INTERFACE.md -->
