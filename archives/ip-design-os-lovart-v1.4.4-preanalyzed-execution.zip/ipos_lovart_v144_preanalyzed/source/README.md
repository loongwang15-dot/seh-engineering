# IP Design OS → Lovart V1.4.2｜完整能力颗粒度部署包

## 目标
把现有 IP Design OS 的全部活跃能力逐项迁移到 Lovart，不因“单文件 Skill”而缩减描述、删除步骤、合并掉生产能力或弱化 QA/锁定/版本/资源治理。

## 15 个活跃 Skill 文件
1. IPOS-MASTER
2. IPOS-CHARACTER
3. IPOS-GIF
4. IPOS-VISUAL-REPORT
5. IPOS-COMIC
6. IPOS-RESOURCE-MANAGER
7. IPOS-STATIC-EMOJI
8. IPOS-VISUAL-DESIGN
9. IPOS-ASSET-INTERFACE
10. IPOS-COLOR
11. IPOS-POSTER
12. IPOS-SIDE-CHARACTER
13. IPOS-TEXT-QA
14. IPOS-THREEVIEW
15. IPOS-WORKWEAR

其中 09–15 原来是 Master extensions，但它们各自有独立 Skill identity / trigger / scope / constraints，因此现在同时提供独立单文件部署版本；Master 内仍保留其逐字原文，保证总控侧也拥有完整接口定义。

## Resource Manager
06_IPOS-RESOURCE-MANAGER.md 包含：原 Resource Manager Skill、README、catalog、全部 PPE 标准资源文本、全部 Scene 标准资源文本，以及两张 PPE 标准参考图片的原始二进制 Base64。

## 零缩水审计
所有源组件均逐字嵌入并记录 bytes / chars / SHA-256。没有以摘要、短版 Prompt 或“能力描述”替代原文。Lovart 运行层只增加跨 Skill 对接和执行边界，不删除源能力。

## Lovart 部署原则
Lovart 官方文档当前说明 Custom Skill 是从成功项目对话保存为可复用 Skill，并要求 Thinking Mode；普通 Upload Files 用于将图片、视频、PDF作为 Agent 对话参考。因此这些文件应逐个作为“完整 Skill 定义”去创建/保存 Custom Skill，而不是把整个 ZIP 当成安装包。

## 推荐顺序
1. 先建立 IPOS-MASTER。
2. 建立 Resource Manager、Asset Interface、Visual Design、Text QA 等基础服务。
3. 建立 Character / Threeview / Workwear / Side Character / Color / Poster / Comic / GIF / Static Emoji / Visual Report。
4. 在 Brand Kit 中沉淀 Logo、颜色、字体、视觉规则。
5. 在 Lovart 的资产/参考体系中沉淀角色、三视图、职业形象、表情、标准参考图。
6. 用真实工伤预防任务跑通 Master → Resource Manager → Primary Skill → Service/QA → Revision → Assetization。

## 重要
16 与 17 是审计文件，不是 Skill。
