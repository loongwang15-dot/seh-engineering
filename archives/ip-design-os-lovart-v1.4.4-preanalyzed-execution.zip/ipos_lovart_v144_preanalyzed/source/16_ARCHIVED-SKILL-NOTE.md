# ARCHIVED SKILL NOTE

The original ip-extension-workflow-master is explicitly disabled/archived and is not deployed as an active Lovart Skill. This avoids Master trigger competition. Historical source is preserved in the original package.

---
name: ip-extension-workflow-master
description: "【已停用】本技能已于 2026-09-25 归档停用，不再执行任何任务。IP 设计、角色延展、物料生产等相关需求请使用 ip-design-os-master。"
status: disabled
version: archived
---

# 已停用（ARCHIVED）

本技能（IP形象延展工作流 Master Skill，一体化部署版）已于 2026-09-25 停用归档。

## 停用原因

- 与 `ip-design-os-master`（分体式 Master，路由独立子 Skill）触发域完全重叠，同时存在会造成触发竞争。
- 按「Master 二选一」决策：以包内分体式架构（IP Design OS Master + 独立 Production Skill）为基准，保留 `ip-design-os-master`，停用本一体化变体。

## 完整原版备份位置

```
C:\Users\AB\Doubao\chats\2026-09-25\new-chat-2\SEH_pkg\archive\ip-extension-workflow-master\
```

包含原 SKILL.md 与全部 references（master_workflow / comic_workflow / visual_design_system / resource_library）。

## 恢复方式

1. 退出豆包客户端（避免技能目录自动重建与文件占用）。
2. 将归档目录 `ip-extension-workflow-master\` 整体复制回：
   `C:\Users\AB\AppData\Local\Doubao\User Data\Default\.doubao\agent_mode\workspace\.user_skills\`
3. 重新打开客户端，技能即恢复可用。

## 说明

本文件保留 `name` 原值以避免加载器混淆；`description` 已改为停用声明，不再命中任何业务触发。此内容级停用不会被客户端自动恢复机制覆盖（经实测验证）。
