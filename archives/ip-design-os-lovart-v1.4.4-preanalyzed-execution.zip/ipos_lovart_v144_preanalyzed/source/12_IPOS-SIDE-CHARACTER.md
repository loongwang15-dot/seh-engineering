# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-SIDE-CHARACTER.md | bytes=7167 | chars=4995 | sha256=90aaf28afb698842c6fd2156d4a697adb6122efd60c42cfee6f7f01cacd9bded -->

---
name: side-character-design
description: "配角形象设计 Skill（Side Character Design Skill v1.0.0）：根据已确定的主 IP，设计与其处于同一视觉体系、同一世界观、同时具有明确身份差异的配角角色。核心原则：配角不是重新创造一个 IP，而是从主 IP DNA 中派生出的角色资产；必须满足视觉统一、角色差异、功能明确、可持续调用（默认 70% 视觉统一 + 30% 角色差异）。触发：设计配角、增加 IP 伙伴、设计第二/辅助/CP/搭档角色、设计 IP 家庭成员、设计 IP 工作伙伴、扩展 IP 角色体系。不得接管：主 IP 从零设计、三视图、表情包、动态表情、场景职业延展、条漫、海报、单纯修改已有配角服装。"
execution_mode: Workflow Controlled
skill_type: IP角色扩展 / 视觉资产生成
skill_version: v1.0.0
status: Production Ready
---

# 配角形象设计 Skill

## Side Character Design Skill

## 1. Skill Definition

### Core Goal

根据已经确定的主
IP，设计与其处于同一视觉体系、同一世界观，同时具有明确身份差异的配角角色。

核心原则：

配角不是重新创造一个 IP，而是从主 IP DNA 中派生出的角色资产。

必须满足：

-   视觉统一
-   角色差异
-   功能明确
-   可持续调用

------------------------------------------------------------------------

# 2. Trigger Rules

触发条件：

-   设计配角
-   增加 IP 伙伴
-   设计第二角色
-   设计辅助角色
-   设计 CP / 搭档角色
-   设计 IP 家庭成员
-   设计 IP 工作伙伴
-   扩展 IP 角色体系

------------------------------------------------------------------------

# 3. Non Trigger Rules

不得接管：

-   主 IP 从零设计
-   三视图制作
-   表情包制作
-   动态表情制作
-   场景职业延展
-   条漫设计
-   海报设计
-   单纯修改已有配角服装

------------------------------------------------------------------------

# 4. Input Interface

## Required Input

-   主 IP 图片或角色信息
-   配角用途或角色关系

## Optional Input

-   配角名称
-   性别
-   年龄感
-   物种
-   性格
-   职业
-   服装方向
-   配色
-   参考图
-   故事背景

## Missing Input Handling

如果配角定位不明确：

先分析主 IP：

-   行业属性
-   角色定位
-   视觉风格
-   IP DNA
-   使用场景

然后提供最多三个设计方向。

------------------------------------------------------------------------

# 5. Output Interface

输出：

1.  配角角色定位卡
2.  配角主视觉形象
3.  配角资产信息

Character Role Card：

-   角色名
-   角色身份
-   角色关系
-   性格关键词 ×3
-   视觉关键词 ×3

------------------------------------------------------------------------

# 6. Workflow

    INPUT_CHECK
    ↓
    PARENT_DNA_LOCK
    ↓
    ROLE_ANALYSIS
    ↓
    ROLE_CONFIRM
    ↓
    CHARACTER_DESIGN
    ↓
    RELATION_COMPOSITION
    ↓
    VISUAL_QA
    ↓
    ASSET_REGISTER
    ↓
    COMPLETE

------------------------------------------------------------------------

# 7. State Machine

状态：

-   IDLE
-   INPUT_CHECK
-   PARENT_DNA_LOCK
-   ROLE_ANALYSIS
-   ROLE_CONFIRM
-   CHARACTER_DESIGN
-   RELATION_COMPOSITION
-   VISUAL_QA
-   ASSET_REGISTER
-   COMPLETE

------------------------------------------------------------------------

# 8. Workflow Lock

进入 PARENT_DNA_LOCK 后：

锁定：

-   主 IP 形象
-   主 IP 色彩
-   主 IP 比例
-   主 IP 视觉风格
-   主 IP 核心特征

禁止在配角设计中修改主 IP。

------------------------------------------------------------------------

# 9. Design Rules

## Visual Unity

保持：

-   世界观
-   画风
-   材质体系
-   光影体系
-   色彩逻辑
-   造型语言

## Character Difference

体现：

-   物种
-   身材
-   性格
-   职业
-   服装
-   辅助色
-   表情
-   动作习惯

原则：

70%视觉统一 + 30%角色差异。

------------------------------------------------------------------------

# 10. Generation Specification

默认：

16:9

第一阶段：

主 IP + 配角关系展示。

要求：

-   干净背景
-   角色完整
-   比例清晰
-   配角身份明确
-   主 IP 保持视觉中心

第二阶段：

生成配角独立标准形象。

------------------------------------------------------------------------

# 11. QA Check System

## IP一致性 QA

检查：

-   是否属于同一视觉体系
-   是否保持主 IP 风格
-   是否保持比例体系
-   是否保持材质体系

## 角色差异 QA

检查：

-   是否与主 IP 过度相似
-   是否具备独立身份
-   是否具备角色功能

## 内容质量 QA

检查：

-   手部
-   脚部
-   五官
-   服装结构
-   色彩
-   材质
-   光影

## 内容污染检查

禁止：

-   随机文字
-   错误 Logo
-   随机徽章
-   多余人物
-   多余特效

------------------------------------------------------------------------

# 12. Error Recovery

失败流程：

    生成
    ↓
    QA
    ↓
    FAIL
    ↓
    错误定位
    ↓
    局部修正
    ↓
    重新生成
    ↓
    QA

默认自动修正：

最多 2 次。

仍失败：

进入 HUMAN_REVIEW。

------------------------------------------------------------------------

# 13. Asset Register

注册：

Side Character Asset

记录：

-   角色名称
-   角色身份
-   角色关系
-   Parent IP
-   Visual DNA
-   主色
-   辅助色
-   比例
-   服装
-   性格
-   参考图
-   版本号
-   状态

------------------------------------------------------------------------

# 14. Version Control

命名：

IP名称-SideCharacter-角色名称-v001

禁止覆盖历史版本。

------------------------------------------------------------------------

# 15. Runtime Observability

记录：

-   skill_name
-   skill_version
-   trigger_reason
-   parent_ip
-   character_name
-   workflow_state
-   input_status
-   dna_lock_status
-   user_confirmation_status
-   generation_status
-   qa_status
-   retry_count
-   asset_version
-   handoff_target
-   completion_status

------------------------------------------------------------------------

# 16. Downstream Interface

输出资产供：

-   三视图 Skill
-   基础表情 Skill
-   动态表情 Skill
-   场景职业 Skill
-   条漫 Skill
-   海报 Skill
-   汇报方案 Skill

调用。

下游优先使用已注册配角资产。

------------------------------------------------------------------------

# 17. Forbidden Actions

禁止：

1.  修改主 IP
2.  改变主 IP 风格
3.  越权执行其他 Skill
4.  随机增加 Logo
5.  随机增加文字
6.  增加无关特效
7.  未确定定位直接生成
8.  用大量文字替代视觉设计

------------------------------------------------------------------------

# 18. Completion Criteria

完成必须满足：

-   主 IP DNA 已锁定
-   配角定位明确
-   角色差异明确
-   视觉体系统一
-   配角主视觉生成
-   QA PASS
-   Asset Register 完成

状态：

COMPLETE


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-SIDE-CHARACTER.md -->
