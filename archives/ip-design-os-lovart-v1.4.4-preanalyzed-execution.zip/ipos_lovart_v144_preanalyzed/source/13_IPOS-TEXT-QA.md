# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 1 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ip-design-os-master/extensions/EXT-TEXTQA.md | bytes=6680 | chars=4618 | sha256=d87b19fea50f1e4a739c08e72d7d1ab31814feeda148f09dbe46eccc5ae2323a -->

---
name: text-qa-skill
description: "底层文字质检 QA Skill v1.0（Text QA Skill）：通用型文字视觉质量检测子 Skill。对 AI 生成的图片、海报、表情包、条漫、IP 物料、汇报页面等视觉结果中的文字进行质量检查。负责：文字存在性、文字完整性、文案一致性、中文字形、缺笔/断笔、乱码、错字、可读性、排版异常、关键文字检查。不负责：创作文案、修改文案、字体设计、重新设计版式、修改 IP、修改画面风格。触发：视觉结果包含文字、用户要求文字检查、上游 Skill 请求 Text QA、进入文字质检节点、包含标题/品牌名/IP名称/宣传语/对白等文字。不主动触发：单纯字体设计、单纯版式调整、无文字图片生成、角色/颜色/场景修改。"
layer: A-Skill-Engineering
status: Production
type: QA
version: 1.0
---

# Text QA Skill

# 文字质检 QA Skill v1.0

## Skill定位

Text QA Skill 是通用型文字视觉质量检测子 Skill。

核心职责：

对 AI
生成的图片、海报、表情包、条漫、IP物料、汇报页面等视觉结果中的文字进行质量检查。

负责： - 文字存在性检查 - 文字完整性检查 - 文案一致性检查 -
中文字形检查 - 缺笔/断笔检测 - 乱码检测 - 错字检测 - 可读性检测 -
排版异常检测 - 关键文字检查

不负责： - 创作文案 - 修改文案 - 字体设计 - 重新设计版式 - 修改IP -
修改画面风格

------------------------------------------------------------------------

# Trigger Rules

必须触发： - 视觉结果包含文字 - 用户要求文字检查 - 上游 Skill 请求 Text
QA - 进入文字质检节点 - 包含标题、品牌名、IP名称、宣传语、对白等文字

不主动触发： - 单纯字体设计 - 单纯版式调整 - 无文字图片生成 -
角色、颜色、场景修改

------------------------------------------------------------------------

# Input Interface

Required:

-   visual_output: 当前视觉结果
-   expected_text: 目标文字（如有）

Optional:

-   text_type
-   font_requirement
-   language
-   layout_requirement
-   critical_text

支持文字类型：

TITLE SUBTITLE BODY DIALOGUE LABEL LOGO_TEXT IP_NAME SLOGAN NUMBER DATE
BUTTON DECORATIVE_TEXT

------------------------------------------------------------------------

# Output Interface

输出：

-   status
-   issue_type
-   location
-   severity
-   recommended_action
-   next_stage

状态：

PASS WARNING FAIL REGENERATE

------------------------------------------------------------------------

# Workflow

执行流程：

INPUT ↓ 读取目标文字 ↓ 文字区域识别 ↓ 文字内容识别 ↓ 目标文案比对 ↓
字符完整性检查 ↓ 中文字形检查 ↓ 乱码检查 ↓ 可读性检查 ↓ 布局检查 ↓
关键文字检查 ↓ QA判定 ↓ 输出状态

------------------------------------------------------------------------

# QA检查机制

## 文字存在性检测

检查目标文字是否出现。

失败： TEXT_MISSING

------------------------------------------------------------------------

## 文字完整性检测

检查： - 缺字 - 多字 - 重复字 - 顺序错误 - 字符替换

------------------------------------------------------------------------

## 中文字体专项检测

重点检测：

-   缺笔
-   断笔
-   偏旁错误
-   字符结构异常
-   伪汉字
-   字形融化
-   笔画断裂

------------------------------------------------------------------------

## 乱码检测

检测：

-   非目标字符
-   随机符号
-   异常英文
-   随机数字

------------------------------------------------------------------------

## 可读性检测

检测：

-   清晰度
-   对比度
-   背景干扰
-   遮挡
-   字号异常

等级：

CLEAR REDUCED UNREADABLE

------------------------------------------------------------------------

## 布局检测

检测：

-   文字溢出
-   裁切
-   遮挡
-   重叠
-   异常断行

------------------------------------------------------------------------

# State Machine

状态流：

Generate → Text QA → PASS → Next Skill

异常：

Text QA → FAIL → Issue定位 → 上游生成节点 → Regenerate → Text QA

最大重试：

MAX_RETRY = 2

超过：

HUMAN_REVIEW

------------------------------------------------------------------------

# Severity Rules

INFO: 无实质问题

WARNING: 轻微变形，可人工确认

FAIL: 明确文字错误

CRITICAL_FAIL: 关键文字错误

关键文字包括： - 标题 - 品牌名称 - IP名称 - 数字 - 日期 - 安全提示

------------------------------------------------------------------------

# Workflow Lock

执行期间：

LOCK: TEXT_QA

禁止其他文字检测模块重复执行。

完成：

UNLOCK: TEXT_QA

------------------------------------------------------------------------

# Error Recovery

错误处理：

1.  定位问题区域
2.  输出错误类型
3.  返回上游生成节点
4.  重新生成
5.  再次执行 Text QA

连续失败：

进入 Human Review。

------------------------------------------------------------------------

# Asset Register

记录：

-   skill_id
-   version
-   input_id
-   source_skill
-   qa_result
-   issue_history
-   retry_count

------------------------------------------------------------------------

# Version Control

Current Version:

1.0

Change Policy:

任何规则调整必须升级版本号。

------------------------------------------------------------------------

# Runtime Observability

记录：

-   skill_id
-   skill_version
-   trigger_source
-   execution_stage
-   qa_status
-   issue_type
-   severity
-   retry_count
-   next_action
-   timestamp

------------------------------------------------------------------------

# Downstream Interface

允许调用：

-   IP Design Skill
-   Poster Design Skill
-   Emoji Design Skill
-   Dynamic Emoji Skill
-   Comic Design Skill
-   Typography Skill

返回：

PASS WARNING FAIL REGENERATE

------------------------------------------------------------------------

# Forbidden Actions

禁止：

-   自行修改文案
-   自行设计字体
-   自行调整布局
-   自行改变IP
-   自行改变配色
-   自行生成完整图片
-   抢占其他Skill执行权
-   重复执行其他QA模块职责

------------------------------------------------------------------------

# Completion Criteria

Skill完成条件：

1.  所有文字检查模块执行完成。
2.  输出明确QA状态。
3.  关键文字通过验证。
4.  错误信息完整记录。
5.  Workflow状态正确释放。

END


<!-- END SOURCE: skills/ip-design-os-master/extensions/EXT-TEXTQA.md -->
