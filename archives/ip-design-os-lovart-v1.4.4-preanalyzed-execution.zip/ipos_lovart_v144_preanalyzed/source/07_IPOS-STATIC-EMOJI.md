# LOVART DEPLOYMENT MODE｜ZERO-CAPABILITY-REDUCTION

This is a COMPLETE Lovart Custom Skill definition.
Do not summarize, shorten, omit, reinterpret, or replace any source capability below. Preserve every trigger, non-trigger, workflow stage, state, lock, QA gate, output, constraint, exception, and governance rule. Redundancy is intentional for deployment fidelity.

## Cross-Skill Contract
- IPOS-MASTER is the sole orchestration authority.
- Every final production task has exactly one Primary Production Skill.
- Service/infrastructure/QA skills advise, retrieve, validate, or govern; they do not steal production ownership.
- IP Master, Character DNA, and locked assets are the Single Source of Truth.
- Resource Manager governs knowledge, standards, provenance, resource packs, and resource lifecycle.
- Asset Interface governs reusable asset identity, version, dependency, transfer, and runtime traceability.
- Visual Design System governs visual rules and visual QA, with only its explicitly permitted system-creation/update/audit ownership.
- Text QA is invoked for consequential text in visual outputs.
- Safety/PPE/cultural/standards-sensitive facts must not be guessed; retrieve them through Resource Manager and elevate review when required.
- Preserve workflow state, locks, versioning, dependency impact, and revision logic.
- If Lovart lacks a native operation, emulate the source decision logic through Agent reasoning/state tracking; never delete the requirement.

## Lovart Runtime Translation
Input → classify → retrieve assets/resources → choose primary owner → execute source workflow → QA → output → asset/version/state registration → revision if needed.
Only mark COMPLETE when the source completion criteria and applicable QA gates pass.

## Deployment Instruction
Use this entire document as the canonical definition when creating/saving the Lovart Custom Skill. Do not replace it with a shortened summary.

# SOURCE-PRESERVATION DECLARATION
This skill embeds 5 source component(s) verbatim.


<!-- BEGIN SOURCE: skills/ipos-static-emoji/SKILL.md | bytes=17500 | chars=11202 | sha256=edc361293f1e98d18e7b8fa6471c9121dfdee9d27c3c251a66d08b0ab5d7d524 -->

---
name: ipos-static-emoji
description: "基础表情包设计 Skill（IP 延展生产型子 Skill，Version v1.1）。当 IP Design OS Master 或用户要求基于已确认 IP 生成基础静态 IP 表情包时使用：默认 8 个高频基础表情、1:1 画布、透明底、自动执行无需用户逐张确认。核心原则：以动作表达情绪、以文字强化语义、以关键帧形成静态表情。上游为 IP Design Workflow Master。"
---

# Basic IP Expression Sticker Skill
# 基础表情包设计 Skill
# Version: v1.1
# Category: A｜Skill撰写与Skill工程
# Type: IP Design OS 下游生产型子 Skill

## 0. Skill Identity

- Skill Name: Basic IP Expression Sticker Skill
- 中文名称: 基础表情包设计 Skill
- Version: v1.1
- Type: IP 延展 / 生产型 / 自动执行
- Upstream: IP Design Workflow Master
- Primary Output: 基础静态 IP 表情包
- Default Set: 8 个高频基础表情
- Default Canvas: 1:1
- Default Background: Transparent
- Execution Mode: Automatic
- User Confirmation: Not required

> 核心原则：以动作表达情绪，以文字强化语义，以关键帧形成静态表情。

---

# 1. Purpose｜Skill目的

将已经确定的 IP 形象自动延展为一套具有高使用频率、高识别度、强动作感、系列一致性和专业字体设计感的基础静态聊天表情。

核心链路：

`语义 → 动作设计 → 动态逻辑 → 关键帧 → 字体设计 → 构图 → 静态表情 → QA → 自动交接`

---

# 2. Core Design Principles｜核心设计原则

## 2.1 动作优先

去掉文字后，用户仍应能够通过动作理解主要语义。

文字不得成为主要情绪表达来源。

## 2.2 动态思维设计静态表情

所有静态表情都按照：

`动作起始 → 动作发展 → 动作强化 → 动作峰值 → 关键帧`

进行设计。

最终优先截取最具表现力的动作峰值。

## 2.3 文字为辅

信息优先级：

`动作 > 表情 > 构图 > 文字`

文字负责强化语义，不代替动作。

## 2.4 专业字体设计

禁止简单使用默认系统字体直接放置。

必须执行：

`语义 → 字体性格 → 字形结构 → 构图关系`

本版本暂不展开 Typography QA 的完整规则，但必须预留 Typography QA 接口。

## 2.5 IP DNA 优先

不得重新设计 IP。必须继承：

- 面部特征
- 身体比例
- 轮廓
- 发型
- 服装
- 主色
- 辅助色
- 标志性特征
- 已确认视觉风格
- 当前 IP 资产版本

## 2.6 系列化

8 张作为一个完整系统设计，保持 IP、视觉风格、字体 DNA、色彩关系、构图语言和视觉重量基本一致。

---

# 3. Trigger Boundary｜触发边界

## 3.1 Trigger When

以下需求触发本 Skill：

- 基础表情包
- 基础表情
- IP表情包
- 静态表情包
- 微信聊天表情
- 8个基础表情
- 吉祥物表情
- IP表情延展
- 给 IP 做聊天表情
- 你好 / 开心 / 点赞 / 收到 / 思考 / 惊讶 / 加油 / 辛苦了等基础表情

## 3.2 Do Not Trigger

| 需求 | 路由 |
|---|---|
| IP创建/修改 | IP形象设计 Skill |
| 三视图 | IP三视图 Skill |
| 色彩规范 | 色彩规范 Skill |
| 视觉规范 | 视觉设计规范 Skill |
| GIF/动态表情 | 动态表情/GIF Skill |
| 海报 | 海报设计 Skill |
| 条漫 | 条漫设计 Skill |
| 平台上架/打包 | 表情包生产/发布 Skill |

本 Skill 可以产生 Action Sequence 和 Key Pose，供动态表情 Skill 使用，但不负责最终 GIF 制作。

---

# 4. Upstream Dependencies｜上游依赖

`IP Design Workflow Master → IP Asset Registry → Basic Expression Sticker Skill`

本 Skill 不负责重新建立 IP 基础资产。

最低要求：

- 已确认 IP 参考图
- 可识别的 IP 形象

优先读取：

- IP名称
- IP DNA
- IP版本
- 三视图
- 角色比例
- 面部特征
- 服装信息
- 色彩系统
- 视觉设计规范
- 已确认视觉风格
- 已批准参考资产

如果 IP 已存在于 Master Workflow，自动读取，不重复询问。

---

# 5. Input Interface｜输入接口

```yaml
ip_reference:
  type: image
  required: true

ip_name:
  type: string
  required: false

ip_version:
  type: string
  required: false

expression_set:
  type: array
  required: false

visual_style:
  type: inherited
  required: true

ip_dna:
  type: inherited
  required: true

color_system:
  type: inherited
  required: false

typography_dna:
  type: inherited_or_generated
  required: false

output_count:
  type: integer
  default: 8

output_ratio:
  type: string
  default: "1:1"

background:
  type: string
  default: "transparent"
```

---

# 6. Default Expression Set｜默认8大基础表情

未指定时自动使用：

| ID | 表情 | 核心动作 |
|---|---|---|
| EX01 | 你好 | 挥手 |
| EX02 | 开心 | 庆祝 / 张臂 |
| EX03 | 点赞 | 👍 |
| EX04 | 收到 | 👌 |
| EX05 | 思考 | 托腮 / 摸下巴 |
| EX06 | 惊讶 | 后仰 / 张嘴 |
| EX07 | 加油 | 握拳上举 |
| EX08 | 辛苦了 | 慰问 / 轻鞠躬 |

8 个为默认基础模板，可扩展：

`8 → 16 → 24 → 主题表情 → 行业表情 → 节日表情`

---

# 7. Expression Unit｜标准表情单元

每个表情必须建立独立 Expression Unit：

```yaml
expression_unit:
  id:
  semantic:
  emotion:
  action:
  action_sequence:
  key_pose:
  typography:
  composition:
  ip_dna:
  output:
```

示例：

```yaml
id: EX04
semantic: 收到
emotion: 确认 / 明白 / 积极回应
action:
  type: OK手势
action_sequence:
  - 手臂准备抬起
  - 手势形成
  - OK手势完成
  - 轻微确认动作
  - 停留
key_pose:
  description: OK手势最清晰、最具识别度的瞬间
typography:
  text: 收到
  role: secondary_information
composition:
  relationship: IP + OK动作 + 前方文字
```

---

# 8. Action Design Engine｜动作设计引擎

每个表情必须建立：

`Start → Development → Peak`

- Start：角色进入动作
- Development：动作逐步形成
- Peak：动作达到最明确、最具表现力的状态

必须找到明确的 Action Peak。

例如：

- 点赞 → 👍形成
- 收到 → 👌形成
- 加油 → 握拳上举
- 你好 → 挥手达到最大幅度

最终静态图优先截取动作峰值。

---

# 9. Dynamic Thinking Interface｜动态接口

本 Skill 不生成最终 GIF，但必须保留：

```yaml
action_sequence:
  start:
  development:
  peak:
  settle:

key_pose:
  pose:
  expression:
  hand_gesture:
  body_direction:
  visual_focus:
```

Action Sequence 可直接交给 Dynamic Expression / GIF Skill，避免重新设计动作。

---

# 10. Typography Design Module｜字体设计模块

文字属于：

> 辅助语义层 + 构图元素

不是主视觉主体。

设计链路：

`表情语义 → 字体性格 → 字形结构 → 视觉动势 → IP关系 → 整体构图`

默认方向：

| 表情 | 字体方向 |
|---|---|
| 你好 | 轻快、开放、友好 |
| 开心 | 活泼、跳跃、饱满 |
| 点赞 | 厚重、有力量、上扬 |
| 收到 | 稳定、明确、紧凑 |
| 思考 | 轻巧、收敛 |
| 惊讶 | 夸张、放大、有张力 |
| 加油 | 强烈、向上、具有冲击力 |
| 辛苦了 | 温暖、柔和、亲和 |

---

# 11. Typography DNA｜字体DNA

统一：

- 字重语言
- 字形气质
- 笔画语言
- 外轮廓语言
- 色彩关系
- 装饰语言

允许变化：

- 倾斜
- 拉伸
- 压缩
- 字距
- 大小
- 构图方向
- 动势

原则：

> 统一字体系统 + 情绪化变体。

禁止 8 张表情使用完全无关联的字体。

---

# 12. Typography Prompt Schema｜字体设计提示词结构

不使用一条固定长 Prompt，采用结构化 Typography Design Spec：

```yaml
typography_spec:
  text:
  semantic:
  emotion:
  style:
  weight:
  structure:
  stroke:
  outline:
  color:
  motion:
  layout:
  relationship_to_ip:
  restrictions:
```

示例：

```yaml
typography_spec:
  text: 点赞
  semantic: 肯定 / 鼓励 / 积极
  emotion: 有力量
  style: 手写艺术字
  weight: heavy
  structure: 紧凑饱满
  stroke: thick
  outline: clean white sticker outline
  color: inherit_ip_visual_system
  motion: slight upward tendency
  layout: foreground_lower_area
  relationship_to_ip: support_action
  restrictions:
    - no_default_system_font
    - no_random_text
    - no_extra_characters
    - no_broken_strokes
```

Typography QA 具体规则后续独立设计。

---

# 13. Typography Placement｜文字构图

文字位置不固定，依据动作和视觉重心自动调整。

示例：

- 点赞：文字可形成视觉底座
- 收到：文字位于 IP 前方
- 你好：文字可顺应挥手方向
- 加油：文字可顺应向上动作

核心：

> 文字参与构图，但不得遮挡核心动作和 IP 关键特征。

---

# 14. Composition Engine｜构图引擎

构图必须同时处理：

`IP主体 + 动作方向 + 文字 + 视觉重心 + 留白 + 安全边距`

规则：

- IP是第一视觉主体
- 核心动作清晰
- 文字辅助动作
- 文字不遮挡脸部
- 文字不遮挡关键手势
- 动作完整
- 构图具有视觉重心
- 保持适当留白

禁止：

- 为丰富画面随意增加背景
- 为丰富画面堆叠道具
- 让文字成为最大视觉主体
- 让装饰抢过 IP

---

# 15. Visual Style Inheritance｜视觉风格继承

本 Skill 不创建新的视觉风格。

必须继承 IP 已确认风格：

- 造型风格
- 比例
- 面部语言
- 服装语言
- 配色
- 材质
- 视觉表现方式

除非上游视觉规范允许，否则禁止无授权切换视觉风格。

---

# 16. Background Rules｜背景规则

默认：

`transparent`

禁止无意义生成：

- 城市
- 办公室
- 公园
- 摄影棚
- 地面
- 随机建筑
- 大面积场景

除非用户明确指定。

---

# 17. Prop Rules｜道具规则

默认无额外道具。

只有当道具能够显著强化语义时允许。

视觉优先级：

`核心动作 > IP > 文字 > 道具`

道具不得成为主要视觉主体。

---

# 18. Generation Specification｜生成规格

```yaml
output:
  count: 8
  ratio: "1:1"
  background: transparent
  format: PNG
  style: inherited_from_ip
  subject: single_IP_character
```

默认要求：

- 完整 IP 主体
- 动作清晰
- 动作峰值明确
- 文字辅助
- 透明背景
- 1:1
- 系列一致

---

# 19. Workflow State Machine｜状态机

```text
IDLE
 ↓
CONTEXT_LOCK
 ↓
IP_VERIFY
 ↓
SEMANTIC_PLAN
 ↓
ACTION_DESIGN
 ↓
ACTION_SEQUENCE
 ↓
KEY_POSE
 ↓
TYPOGRAPHY_PLAN
 ↓
COMPOSITION_PLAN
 ↓
GENERATE
 ↓
ITEM_QA
 ├── FAIL → AUTO_REPAIR → ITEM_QA
 └── PASS
       ↓
SET_QA
 ├── FAIL → AUTO_REPAIR → SET_QA
 └── PASS
       ↓
FINALIZE
 ↓
HANDOFF
```

---

# 20. Human Intervention Policy｜人工介入规则

本 Skill 为生产型自动 Skill。

默认：

**不设置用户确认节点。**

不要求用户确认：

- 表情语义
- 动作方案
- 字体方案
- 单张结果
- 整套结果

正常流程：

`输入 → 自动设计 → 自动生成 → 自动修复 → 自动质检 → 自动放行 → 自动交接`

仅在以下情况向 Master Skill 报告异常：

1. 缺少必要 IP 资产
2. IP版本无法确定
3. 上游资产存在冲突
4. 自动修复达到最大次数仍无法通过 QA
5. 当前任务违反本 Skill 输入契约

除此之外不暂停、不等待、不要求用户确认。

---

# 21. Item QA｜单张质检

## IP Consistency

- 面部
- 轮廓
- 服装
- 比例
- 配色
- 核心特征

## Action Semantics

- 动作符合目标语义
- 动作清晰
- 动作峰值明确
- 无异常肢体

## Composition

- IP突出
- 动作完整
- 文字不遮挡 IP
- 文字不遮挡动作
- 视觉重心稳定

## Output

- 1:1
- 透明背景
- 无随机背景
- 无多余元素

---

# 22. Set QA｜整套质检

检查：

- 8张 IP一致
- 风格一致
- 字体 DNA 一致
- 色彩关系一致
- 构图语言一致
- 视觉重量基本一致
- 动作区分度足够
- 不出现明显重复表达
- 不出现明显风格漂移

---

# 23. Typography QA Interface｜字体QA接口

本版本暂不展开 Typography QA 具体规则。

预留：

```text
Typography Design
        ↓
Typography QA
        ↓
PASS / REPAIR / FAIL
```

未来 Typography QA 负责：

- 中文文字内容准确性
- 错字
- 漏字
- 多字
- 笔画完整性
- 汉字结构完整性
- 字形变形
- 字距
- 字重
- 描边
- 字体一致性
- 文字与动作关系

---

# 24. Auto Repair｜自动修复

QA失败时优先局部修复，不优先整图重生成。

顺序：

`局部文字问题 → 局部构图问题 → 局部动作问题 → IP一致性问题 → 整图重生成`

示例：

- 手部异常 → 修复手部
- 文字区域异常 → Typography Repair
- 文字位置异常 → Typography Layout Repair
- 构图异常 → Composition Repair
- IP变形 → IP Consistency Repair

---

# 25. Retry Limit｜自动修复上限

默认：

`单项最多自动修复 2 次`

如果仍失败：

`NEED_REVIEW`

然后：

- 不阻塞其他表情
- 继续处理其他任务
- 最终由 Master Skill 决定异常项处理策略

---

# 26. Auto Release｜自动放行

条件：

`Item QA = PASS AND Set QA = PASS`

则：

`FINALIZE`

无需用户确认。

---

# 27. Output Interface｜输出接口

```yaml
expression_pack:
  name:
  version:
  status: PASS

  count: 8

  assets:
    format: PNG
    ratio: "1:1"
    background: transparent

  expressions:
    - id:
      semantic:
      emotion:
      action:
      action_sequence:
      key_pose:
      typography_spec:
      asset:

  qa:
    item_qa: PASS
    set_qa: PASS
    typography_qa:
      status: PENDING_MODULE

  handoff:
    status: READY
    next_stage:
```

---

# 28. Dynamic GIF Handoff｜动态表情接口

本 Skill 输出：

### A. Static Key Pose

供基础静态表情使用。

### B. Action Sequence

供 Dynamic Expression / GIF Skill 使用。

```text
Basic Expression Skill
        │
        ├── Static Key Pose
        │        ↓
        │   Static Sticker
        │
        └── Action Sequence
                 ↓
          Dynamic GIF Skill
```

动态 GIF Skill 不重新设计动作。

---

# 29. Workflow Lock｜工作流锁定

进入本 Skill 后自动锁定：

- IP版本
- IP DNA
- 表情集合
- 动作逻辑
- Typography DNA
- 输出规格

本 Skill 不得越权执行：

- IP重新设计
- 三视图
- 海报
- 条漫
- GIF最终制作
- 平台发布

---

# 30. Runtime Observability｜运行观测

内部运行记录：

```yaml
runtime:
  skill_name:
  skill_version:
  trigger:
  ip_version:
  expression_set:
  current_stage:
  generated_count:
  item_qa_pass:
  item_qa_fail:
  repair_count:
  typography_qa_status:
  set_qa_status:
  final_status:
  handoff_status:
```

用户侧仅显示简洁进度：

```text
基础表情包

IP锁定       ✓
语义规划     ✓
动作设计     ✓
字体设计     ✓
批量生成     ●
自动质检     ○
自动交接     ○
```

不得暴露内部推理过程。

---

# 31. Prompt Assembly｜生成提示词组装原则

不依赖一条固定长 Prompt。

由以下模块组装：

`IP DNA + Visual Style + Expression Semantic + Action Design + Key Pose + Typography Spec + Composition + Output Constraints + Negative Constraints`

优先级：

1. IP DNA
2. Action / Expression
3. Key Pose
4. Composition
5. Typography
6. Decorative Elements

任何低优先级内容不得覆盖 IP DNA 和动作语义。

---

# 32. Prompt Negative Constraints｜负向约束

默认：

```text
no redesign of the character,
no change of clothing,
no change of color system,
no style drift,
no random background,
no unnecessary props,
no extra characters,
no duplicated limbs,
no malformed hands,
no distorted face,
no cropped body,
no random symbols,
no random text,
no unnecessary decorative elements
```

中文：

```text
保持原IP形象一致；
不得重新设计角色；
不得改变服装；
不得改变主要配色；
不得改变既定视觉风格；
透明背景；
无随机场景；
无多余人物；
无无意义道具；
避免手部结构错误；
避免肢体重复；
避免脸部变形；
避免主体裁切；
避免随机文字；
避免乱码；
避免无意义装饰。
```

---

# 33. Default Prompt Logic｜默认生成逻辑

系统内部按照：

`[IP身份锁定] + [目标表情语义] + [动作序列] + [动作峰值] + [IP视觉风格] + [字体设计规范] + [构图关系] + [1:1透明背景] + [一致性约束]`

生成。

不得在每次执行中随意改变核心结构。

---

# 34. Asset Versioning｜资产版本

默认：

`ExpressionPack_v1.0`

后续：

`v1.1 / v1.2 / v2.0`

版本变化必须记录：

- IP版本
- 表情集合
- 动作版本
- Typography DNA版本
- QA状态
- 修改原因

禁止无记录覆盖已批准资产。

---

# 35. Completion Definition｜完成定义

只有满足：

- 8个基础表情全部生成
- Item QA通过
- Set QA通过
- 输出规格正确
- IP一致性通过
- Typography QA 接口状态正常

才可以：

`FINALIZE = PASS`

然后：

`HANDOFF = READY`

---

# 36. Skill Boundary Summary｜最终边界

本 Skill 负责：

> 将已经确定的 IP 自动转化为以动作语义为核心、以字体为辅助、以动态关键帧思维设计的基础静态表情包。

本 Skill 不负责：

> IP创建、IP修改、三视图、全局视觉规范、色彩规范、GIF最终制作、海报、条漫、平台发布。

---


<!-- END SOURCE: skills/ipos-static-emoji/SKILL.md -->


<!-- BEGIN SOURCE: skills/ipos-static-emoji/README.md | bytes=995 | chars=539 | sha256=a23f2486c78bba083169217831654a1b305d3525d7455166dfccb5ffce2fd151 -->

# ipos-static-emoji · 基础表情包设计 Skill

版本：v1.1 · 类型：IP 延展生产型子 Skill

## 功能
基于已确认的 IP 形象生成基础静态 IP 表情包：
- 默认 8 个高频基础表情（开心、难过、生气、惊讶、点赞、OK、疑问、比心等，按上游指令）
- 1:1 画布、透明底
- 自动执行，无需用户逐张确认

## 核心原则
1. 以动作表达情绪——表情靠身体语言和姿态传达
2. 以文字强化语义——必要时配短文字强化含义
3. 以关键帧形成静态表情——取最有辨识度的一帧定格

## 上下游
- 上游：IP Design OS Master（`ip-design-os-master`）——提供已确认的 IP 核心资产与设定
- 产出：供 `ipos-comic`（条漫）、`ip-sticker-gif-batch`（动态表情）等下游复用

## SEH 部署
- skill_id：`skill.ipos-static-emoji.v1.1`
- 已注册：seh-engineering/registry/registry.json
- 纳入方式：seh-skill-manager pipeline（--fix 补齐包结构）


<!-- END SOURCE: skills/ipos-static-emoji/README.md -->


<!-- BEGIN SOURCE: skills/ipos-static-emoji/CHANGELOG.md | bytes=80 | chars=66 | sha256=54d488cd58a31e1d27551071ceb2008ec1e4ed7bb163955ae04d614b61764661 -->

# Changelog

## 1.1 (2026-09-25)
- 由 seh-skill-manager 补齐包结构。


<!-- END SOURCE: skills/ipos-static-emoji/CHANGELOG.md -->


<!-- BEGIN SOURCE: skills/ipos-static-emoji/VERSION | bytes=5 | chars=5 | sha256=d8bb74080a94aa97d78e90f9a656c6a75216e55736f53d5433a0812c5dbc2ec4 -->

1.1


<!-- END SOURCE: skills/ipos-static-emoji/VERSION -->


<!-- BEGIN SOURCE: skills/ipos-static-emoji/manifest.yaml | bytes=79 | chars=79 | sha256=227d3417b8e71ed2cbc12a26b04fcd236b7d7eb1bdca48c6ee9236d7e4604f5f -->

skill_id: skill.ipos-static-emoji.v1.1
name: ipos-static-emoji
version: 1.1


<!-- END SOURCE: skills/ipos-static-emoji/manifest.yaml -->
